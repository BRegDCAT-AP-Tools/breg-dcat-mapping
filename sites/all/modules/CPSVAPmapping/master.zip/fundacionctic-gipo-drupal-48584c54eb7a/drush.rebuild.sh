#!/bin/bash
echo "Rebuilding..."
rm -r ../gipo-distro
drush make gipo.make ../gipo-distro
cp -r profiles ../gipo-distro
cp -r sites ../gipo-distro
