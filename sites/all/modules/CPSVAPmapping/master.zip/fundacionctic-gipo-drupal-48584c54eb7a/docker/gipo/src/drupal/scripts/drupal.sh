#!/bin/bash

mkdir /opt/drupal
cd /opt/drupal
FILE="/opt/drupal/master.zip"
 
if [ -f "$FILE" ];
then
   echo 'Deleting previous version'
   rm -f master.zip
   rm -rf fundacionctic-gipo-drupal*
fi
wget --user=integracion@fundacionctic.org --password=43q4sDf3U https://bitbucket.org/fundacionctic/gipo-drupal/get/master.zip
unzip master.zip
cd fundacionctic-gipo-drupal*
drush make gipo.make --no-core ../gipo-no-core
cp -r sites ../gipo-no-core
chown -R www-data:www-data /opt/drupal/gipo-no-core
cp -r ../gipo-no-core/sites /var/www/html
cp -r profiles /var/www/html
#cd ../gipo-distro
#a2dissite 000-default
#a2ensite gipo
chown -R www-data:www-data /var/www/html

update-rc.d cron defaults
(crontab -l ; echo "*/6 * * * * curl http://localhost/cron.php?cron_key=cdhTdk7CcU-M_J470q6BpKsrDWyZ9-FFyyEtPJirjO8 >/dev/null 2>&1")| crontab -
