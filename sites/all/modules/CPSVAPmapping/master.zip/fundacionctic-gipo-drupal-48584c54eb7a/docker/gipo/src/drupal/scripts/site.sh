#!/bin/bash
#
# site.sh nombre_sitio
#
#

echo "Building GIPO site"

cd /var/www/html

drush si gipo_profile -y --db-url="mysql://gipo:gipo@mysql/gipo" --db-su=root --db-su-pw=secreta --account-name=admin --account-pass=admin --site-name=GIPO
drush -y dl memcache

drush default vset block_cache 1
drush default vset --exact cache 1
drush default vset page_cache_maximum_age 900
drush default vset configurable_timezones 1
drush default vset date_default_timezone "Europe/Madrid"
drush default vset site_default_country "ES"
drush default vset date_first_day 1

# drush -y default l10n-update-refresh
# drush -y default l10n-update

echo "<?php" > /tmp/sites.php
echo "\$sites['48888.localhost'] = 'default';" >> /tmp/sites.php
cp /tmp/sites.php ./sites
echo "\$base_url='http://gipo.fundacionctic.org';" >> ./sites/default/settings.php

echo "\$conf['reverse_proxy'] = TRUE;" >> ./sites/default/settings.php
echo "\$conf['reverse_proxy_addresses'] = array('127.0.0.1',);" >> ./sites/default/settings.php
#echo "\$conf['cache_backends'][] = 'sites/all/modules/contrib/memcache/memcache.inc';" >> ./sites/default/settings.php
#echo "\$conf['cache_default_class'] = 'MemCacheDrupal';" >> ./sites/default/settings.php
#echo "\$conf['memcache_key_prefix'] = 'default';" >> ./sites/default/settings.php

#drush default -y en memcache
