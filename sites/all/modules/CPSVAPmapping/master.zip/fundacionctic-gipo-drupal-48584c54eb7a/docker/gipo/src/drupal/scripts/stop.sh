#!/bin/bash

/etc/init.d/ssh stop
/etc/init.d/mysql stop
/etc/init.d/apache2 stop
