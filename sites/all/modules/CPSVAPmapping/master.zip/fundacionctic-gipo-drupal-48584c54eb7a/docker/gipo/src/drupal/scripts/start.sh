#!/bin/bash

#/etc/init.d/ssh start
#/etc/init.d/mysql start
#/etc/init.d/memcached start
/etc/init.d/apache2 start
/etc/init.d/cron start

FILE="/var/www/html/sites/default/settings.php"
 
if [ ! -f "$FILE" ];
then
   echo "GIPO distro not found."
   echo "Installing GIPO distro (will take some minutes)."
   sleep 30
   cd /var/www/html
   drush si gipo_profile -y --db-url=mysql://gipo:gipo@mysql/gipo --db-su=root --db-su-pw=secreta --account-name=admin --account-pass=admin
   drush en gipo_search -y
   drush dl drush_language
   drush langimp es profiles/gipo_profile/translations/gipo_profile-0.1-beta.es.po --groups=taxonomy
   drush language-refresh
fi
chown -R www-data:www-data /var/www/html/sites/default/files
tail -f /var/log/apache2/error.log
