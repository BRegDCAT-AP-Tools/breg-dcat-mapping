#!/bin/bash

#if [ -e "/var/lib/tomcat7/webapps/viewer/WEB-INF/classes/bbdd.properties" ]; then
	~/scripts/start.sh
#else
#	~/scripts/init.sh
#fi
                
exec tail -f /var/log/apache2/error.log

