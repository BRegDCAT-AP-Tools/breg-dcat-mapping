#!/bin/bash

#######
# SSH #
#######
echo "************* Iniciando SSH ***************"
service ssh start

##########
# DRUPAL #
##########
echo "************* Iniciando DRUPAL ***************"
service mysql start
service apache2 start
