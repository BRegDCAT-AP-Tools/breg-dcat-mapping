<?php

/**
 * Description of BlackListedTagsPostProcessor
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */
class BlackListedTagsPostProcessor {

  private $blackList;

  public function __construct(array $black_list) {
    $this->blackList = $black_list;
  }

  public function process(&$vigilancia_item) {
    if (isset($vigilancia_item['tags'])) {
      $vigilancia_item['tags'] = array_values(array_diff($vigilancia_item['tags'], $this->blackList));
    }
  }

}
