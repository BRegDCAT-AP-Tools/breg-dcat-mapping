<?php

/**
 * @file
 * Description of SolrUpdateJSONBuilder.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Builds a JSON document for Solr update Request.
 */
class SolrUpdateJSONBuilder {

  protected $id;
  protected $newValues;

  /**
   * Builds an JSON builder object.
   *
   * @param string $id
   *   The id of the solr document (in this case the url).
   * @param array $new_values
   *   The new values to update the solr document.
   *   Each key is a solr field and value is the new value of the field (should be another array for multivalue fields).
   */
  public function __construct($id, $new_values) {
    $this->id = $id;
    $this->newValues = $new_values;
  }

  /**
   * Builds a JSON formatted to update a Solr document.
   *
   * @return string
   *   A JSON formatted with the update information.
   */
  public function build() {
    $update_document = array(
      $this->createClass()
    );
    return json_encode($update_document);
  }

  /**
   * Creates a object with the update information.
   *
   * @return \stdClass
   */
  private function createClass() {
    $doc = new stdClass();
    $doc->id = $this->id;
    foreach ($this->newValues as $field => $values) {
      $set_operation = new stdClass();
      $set_operation->set = $values;
      $doc->{$field} = $set_operation;
    }
    $doc->gipo_last_updated = (object) array('set' => 'NOW');
    return $doc;
  }

}
