<?php

/**
 * @file
 * Test FilterUtils.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

require_once dirname(__FILE__) . '/../FilterUtils.php';
require_once dirname(__FILE__) . '/../TaxonomyTermExtractor.php';

/**
 *
 */
class FilterUtilsTest extends PHPUnit_Framework_TestCase {

  /**
   * @covers FilterUtils::transformDrupalFilter
   * @todo   Implement testTransformDrupalFilter().
   */
  public function testTransformDrupalFilter() {
    // Node object as exported with NodeImport module.
    $node = (object) array(
      'vid' => '18',
      'uid' => '0',
      'title' => 'Accessible',
      'log' => '',
      'status' => '1',
      'comment' => '2',
      'promote' => '0',
      'sticky' => '0',
      'vuuid' => 'fdd50790-6c1e-44b0-bcf8-ea8671c702e0',
      'nid' => '18',
      'type' => 'filter',
      'language' => 'und',
      'created' => '1455092525',
      'changed' => '1458140896',
      'tnid' => '0',
      'translate' => '0',
      'uuid' => '27f71a09-980e-4e30-bd94-53293374f437',
      'revision_timestamp' => '1458140896',
      'revision_uid' => '1',      
      'field_aspects' => array(
        'und' => array(
          array(
            'tid' => '46',
          ),
          array(
            'tid' => '19',
          ),
        ),
      ),
      'field_reg_exp' => array(
        'und' => array(
          array(
            'value' => '/field_reg_exp value 1 (en)/i',
            'format' => NULL,
            'safe_value' => '/field_reg_exp value 1 (en)/i',
          ),
          array(
            'value' => '/field_reg_exp value 2 (es)/i',
            'format' => NULL,
            'safe_value' => '/field_reg_exp value 2 (es)/i',
          ),
        ),
      ),
      'field_filter_language' => array(
        'und' => array(
          array('value' => 'en'),
          array('value' => 'es'),
        )
      ),
      // Other node fields removed for simplicity.
    );
    $filter_utils = new FilterUtils(new HashMapTaxonomyTermExtractor());
    $result = $filter_utils->transformDrupalFilter($node);
    $expected_result = array(
        'title' => 'Accessible',
        'classify_into' => 'gipo_aspects',
        'value' => array('Development', 'Security'),
        'field' => array('title', 'description'),
        'field_reg_exp' => array(
          '/field_reg_exp value 1 (en)/i',
          '/field_reg_exp value 2 (es)/i',
        )
    );

    $this->assertEquals($expected_result, $result);
  }

}

class HashMapTaxonomyTermExtractor implements TaxonomyTermExtractor {
    private $terms = array(
        '46' => 'Development',
        '19' => 'Security',
    );
    
    public function getTaxonomyTerm($term_id) {
        return $this->terms[$term_id];
    }

}
