<?php

/**
 * @file DiscoverCandidatesManager.php
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */
module_load_include('inc', 'gipo_rss', 'libraries/http_request');

/**
 * Description of DiscoverCandidatesManager.
 */
class DiscoverCandidatesManager {

  /**
   * Search the home page of a host for RSS feeds.
   *
   * @param string $domain
   *   The domain to search.
   *
   * @return array
   *   An array with info about all RSS feeds found and the home page itsef.
   */
  public function discover($domain) {
    $verified_feeds = array();
    $url = 'http://' . $domain;
    try {
      $response = http_request_get($url);
      if ($this->isValidCodeResponse($response->code)) {
        if ($this->isHtml($response)) {
          $verified_feeds[] = $this->createWebpageCandidate($response, $url);
          $feed_candidates = $this->extractRssCandidates($url);
          foreach ($feed_candidates as $feed_url) {
            $feed = $this->verifyFeed($feed_url);
            if ($feed['adecuate']) {
              $verified_feeds[] = $feed;
            }
          }
        }
        elseif ($this->isRss($response)) {
          $feed = $this->verifyFeed($url);
          if ($feed['adecuate']) {
            $verified_feeds[] = $feed;
          }
        }
      }
    }
    catch (HRCurlException $e) {
      
    }

    return $verified_feeds;
  }

  /**
   * Search the home page of a host for RSS feeds only.
   *
   * @param string $domain
   *   The domain to search.
   *
   * @return array
   *   An array with info about all RSS feeds found.
   */
  public function getVerifiedRss($domain) {
    $verified_feeds = array();
    $url = 'http://' . $domain;
    try {
      $response = http_request_get($url);

      if ($this->isHtml($response)) {
        $feed_candidates = $this->extractRssCandidates($url);
        foreach ($feed_candidates as $feed_url) {
          $feed = $this->verifyFeed($feed_url);
          if ($feed['adecuate']) {
            $verified_feeds[] = $feed;
          }
        }
      }
    }
    catch (HRCurlException $e) {
      
    }

    return $verified_feeds;
  }

  /**
   * Checks if is a valid http code response (2XX).
   *
   * @param int $http_code
   *   The http code returned.
   *
   * @return bool
   *   True if the code is 2XX or false otherwise
   */
  private function isValidCodeResponse($http_code) {
    return $http_code >= 200 && $http_code < 300;
  }

  /**
   * Gets the feeds info from a page.
   *
   * @param string $url
   *   An url where extract the feeds from.
   *
   * @return array
   *   An array with the title, absolute url and a flag if the contents pases
   *   the GIPO filters.
   */
  private function extractRssCandidates($url) {
    $html = http_request_get($url);
    $url_candidates = http_request_find_feeds($html->data);
    $feed_candidates = array();
    foreach ($url_candidates as $url_candidate) {
      $feed_candidates[] = http_request_create_absolute_url($url_candidate, $url);
    }

    return $feed_candidates;
  }

  /**
   * Gets the feed title and checks if it is adecuate (talks about GIPO topics).
   *
   * @param string $url
   *   The url to verify.
   *
   * @return array
   *   Returns an array with the RSS data.
   */
  private function verifyFeed($url) {    
    if (strpos($url, '/comments') !== FALSE) {
      // RSS feeds for comments are discarded.
      return array('adecuate' => FALSE);
    }
    $vigilancia_data = _vigilancia_retrieve_resource($url, _vigilancia_importador_get_instance('rss', array()), array());
    if ($vigilancia_data === FALSE) {
      return array('adecuate' => FALSE);
    }

    if (!is_object($vigilancia_data)) {
      // Marcamos un límite al número de elementos que se clasificarán (en "feeds" muy extensos se produce un gran retardo).
      $limit = 25;
      // Ejecutamos los clasificadores de texto (si estamos con una fuente cacheada solo se procesarán aquellos que no hubiesen sido procesados previamente).
      $clasificadores = array();
      // No saturamos opencalais
      // $clasificadores[] = _vigilancia_clasificador_get_instance('opencalais', '');.
      if (module_exists('gipo_cliff')) {
        $clasificadores[] = _vigilancia_clasificador_get_instance('cliff', variable_get('gipo_cliff_url'));
      }

      $filter_nodes = gipo_rss_get_all_filter_nodes();
      $filter_utils = new FilterUtils(new DrupalTaxonomyTermExtractor());
      $filters = array();
      foreach ($filter_nodes as $filter_node) {
        $filters[] = $filter_utils->transformDrupalFilter($filter_node);
      }
      $regexp_classifier = new RegExpFeedItemClassifier($filters);
      foreach ($vigilancia_data['items'] as $vigilancia_item) {
        if ($limit > 0) {
          $limit--;
          foreach ($clasificadores as $clasificador) {
            $clasificador->process($vigilancia_item);
          }
          $regexp_results = $regexp_classifier->classify($vigilancia_item);
          if (isset($regexp_results['gipo_aspects']) && is_array($regexp_results['gipo_aspects']) && array_count_values($regexp_results['gipo_aspects']) > 0) {
            return array(
              'title' => $vigilancia_data['title'],
              'url' => $url,
              'source_type' => 'feed',
              'adecuate' => TRUE,
            );
          }
        }
      }
      return array('title' => $vigilancia_data['title'], 'adecuate' => FALSE);
    }
    else {
      return array('adecuate' => FALSE);
    }
  }

  /**
   *
   */
  private function createWebpageCandidate($response, $url) {
    return array(
      'title' => $this->extractTitle($response->data, $url),
      'url' => $url,
      'source_type' => 'page',
    );
  }

  /**
   * Extracts the title from HTML or related document.
   *
   * @param string $content
   *   The markup document (html) to extract the title from.
   * @param string $default_value
   *   A string with a default value if no title was found.
   *
   * @return string
   *   Returns the text of the title tag if exists or the provided default value
   *   otherwise.
   */
  private function extractTitle($content, $default_value = 'No title') {
    $matches = array();
    $title = preg_match('/<title[^>]*>(.*?)<\/title>/ims', $content, $matches) ? $matches[1] : '';
    if (strlen($title) == 0) {
      return $default_value;
    }
    else {
      return html_entity_decode(trim($title));
    }
  }

  /**
   * Checks if an http response is a HTML resource.
   *
   * @param object $response
   *   The HTTP response.
   *
   * @return bool
   *   True if the response is a HTML resource or false otherwise.
   */
  private function isHtml($response) {
    if (isset($response->headers['content-type'])) {
      $pos = strpos($response->headers['content-type'], ';');
      if ($pos !== FALSE) {
        $content_type = strtolower(substr($response->headers['content-type'], 0, $pos));
      }
      $content_type = strtolower($response->headers['content-type']);
      if (strpos($content_type, 'html') !== FALSE) {
        return TRUE;
      }
    }
    elseif (isset($response->data)) {
      return strpos($response->data, '<html') !== FALSE;
    }

    return FALSE;
  }

  /**
   * Checks if an http response is a HTTP resource.
   *
   * @param object $response
   *   The HTTP response.
   *
   * @return bool
   *   True if the response is a HTTP resource or false otherwise.
   */
  private function isRss($response) {
    return http_request_is_feed($response->headers['content-type'], $response->data);
  }

}
