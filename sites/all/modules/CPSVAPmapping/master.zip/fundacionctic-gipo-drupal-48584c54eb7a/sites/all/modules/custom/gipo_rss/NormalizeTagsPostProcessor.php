<?php

/**
 * @file
 * Description of NormalizeTagsPostProcessor.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Normalizes tags.
 */
class NormalizeTagsPostProcessor {

  private $equivalentTags;

  /**
   * Create a new object with the optional equivalent tags array.
   *
   * @param array $equivalent_tags
   *   An array with tags that should be considered equivalents.
   */
  public function __construct(array $equivalent_tags = array()) {
    $this->equivalentTags = $equivalent_tags;
  }

  /**
   * Process an item.
   *
   * Converts all tags to lower case, replaces _ for spaces and removes
   * duplicates values.
   *
   * @param array $vigilancia_item
   *   Modifies vigilancia item tags.
   */
  public function process(&$vigilancia_item) {
    if (isset($vigilancia_item['tags'])) {
      $normalized_tags = array();
      foreach ($vigilancia_item['tags'] as $tag) {
        $normalized_tag = str_replace('_', ' ', strtolower($tag));
        $normalized_tags[] = $this->searchEquivalent($normalized_tag);
      }
      $unique_tags_array = array_values(array_unique($normalized_tags));
      if (array_count_values($unique_tags_array) > 20) {
        $vigilancia_item['tags'] = array_slice($unique_tags_array, 0, 20);
      }
      else {
        $vigilancia_item['tags'] = $unique_tags_array;
      }
    }
  }

  /**
   * Search for an equivalent tag.
   *
   * @param string $tag
   *   The tag to check if it has an equivalent.
   *
   * @return string
   *   The tag equivalent if it exists or the original tag otherwise.
   */
  private function searchEquivalent($tag) {
    if (array_key_exists($tag, $this->equivalentTags)) {
      return $this->equivalentTags[$tag];
    }
    else {
      return $tag;
    }
  }

}
