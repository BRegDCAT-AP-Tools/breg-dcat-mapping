<?php
/**
 * @file
 * Default theme implementation for displaying a single search result.
 *
 * This template renders a single search result and is collected into
 * search-results.tpl.php. This and the parent template are
 * dependent to one another sharing the markup for definition lists.
 *
 * Available variables:
 * - $url: URL of the result.
 * - $title: Title of the result.
 * - $snippet: A small preview of the result. Does not apply to user searches.
 * - $info: String of all the meta information ready for print. Does not apply
 *   to user searches.
 * - $info_split: Contains same data as $info, split into a keyed array.
 * - $module: The machine-readable name of the module (tab) being searched, such
 *   as "node" or "user".
 * - $title_prefix (array): An array containing additional output populated by
 *   modules, intended to be displayed in front of the main title tag that
 *   appears in the template.
 * - $title_suffix (array): An array containing additional output populated by
 *   modules, intended to be displayed after the main title tag that appears in
 *   the template.
 *
 * Default keys within $info_split:
 * - $info_split['type']: Node type (or item type string supplied by module).
 * - $info_split['user']: Author of the node linked to users profile. Depends
 *   on permission.
 * - $info_split['date']: Last update of the node. Short formatted.
 * - $info_split['comment']: Number of comments output as "% comments", %
 *   being the count. Depends on comment.module.
 *
 * Other variables:
 * - $classes_array: Array of HTML class attribute values. It is flattened
 *   into a string within the variable $classes.
 * - $title_attributes_array: Array of HTML attributes for the title. It is
 *   flattened into a string within the variable $title_attributes.
 * - $content_attributes_array: Array of HTML attributes for the content. It is
 *   flattened into a string within the variable $content_attributes.
 *
 * Since $info_split is keyed, a direct print of the item is possible.
 * This array does not apply to user searches so it is recommended to check
 * for its existence before printing. The default keys of 'type', 'user' and
 * 'date' always exist for node searches. Modules may provide other data.
 * @code
 *   <?php if (isset($info_split['comment'])): ?>
 *     <span class="info-comment">
 *       <?php print $info_split['comment']; ?>
 *     </span>
 *   <?php endif; ?>
 * @endcode
 *
 * To check for all available data within $info_split, use the code below.
 * @code
 *   <?php print '<pre>'. check_plain(print_r($info_split, 1)) .'</pre>'; ?>
 * @endcode
 *
 * @see template_preprocess()
 * @see template_preprocess_search_result()
 * @see template_process()
 */
?>
<li class="<?php print $classes; ?>"<?php print $attributes; ?>>
    <div class="search-info">
        <?php print render($title_prefix); ?>
        <div class="search-result field-title">
            <h3 class="title"<?php print $title_attributes; ?>>
                <a href="<?php print $redirect_link; ?>"><?php print $title; ?></a>
            </h3> 
        </div>        
        <?php print render($title_suffix); ?>
        <?php if ($source): ?>
          <div class="search-source"><?php print t('Source'); ?>: <?php print $source; ?></div>
        <?php endif; ?>
        <?php if ($snippet): ?>
          <div class="search-result search-snippet"<?php print $content_attributes; ?>><?php print $snippet; ?></div>
        <?php endif; ?>
        <div class="categorization">
            <?php if (isset($gipo_aspects)): ?>
              <div class="search-aspects"><?php print $gipo_aspects; ?></div>
            <?php endif; ?>
            <?php if (isset($gipo_type)): ?>
              <div class="search-type"><?php print $gipo_type; ?></div>
            <?php endif; ?>
            <?php if (isset($gipo_world_regions)): ?>
              <div class="search-world-regions"><?php print $gipo_world_regions; ?></div>
            <?php endif; ?>              
            <?php if (isset($tags)): ?>
              <div class="search-tags"><?php print $tags; ?></div>
            <?php endif; ?>
        </div>
    </div>  
    <div class="search-complementary">
        <?php if ($created): ?>
          <div>
              <time datetime="<?php print $datetime; ?>"><?php print $datetime; ?></time>
              <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" href="#" title="<?php print t('Share this'); ?>">
                  <span class="fa fa-share-alt"></span><span class="hidden"><?php print t('Share this'); ?></span>
              </a>
              <ul class="share-buttons dropdown">
                  <li>
                      <a href="https://www.facebook.com/sharer/sharer.php?u=<?php print $url; ?>&t=<?php print $title; ?>" target="_blank" title="<?php print t('Share on Facebook'); ?>">
                          <span class="fa fa-facebook-square"></span><span class="hidden"><?php print t('Share on Facebook'); ?></span>
                      </a>
                  </li>
                  <li>
                      <a href="https://twitter.com/intent/tweet?source=<?php print urlencode($url); ?>&text=<?php print $title .': ' . urlencode($url); ?>" target="_blank" title="<?php print t('Tweet'); ?>">
                          <span class="fa fa-twitter-square"></span><span class="hidden"><?php print t('Tweet'); ?></span>
                      </a>
                  </li>
                  <li>
                      <a href="https://plus.google.com/share?url=<?php print $url; ?>" target="_blank" title="<?php print t('Share on Google+'); ?>">
                          <span class="fa fa-google-plus-square"></span><span class="hidden"><?php print t('Share on Google+'); ?></span>
                      </a>
                  </li>
                  <li>
                      <a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php print $url; ?>&title=<?php print $title; ?>&source=<?php print $url; ?>" target="_blank" title="<?php print t('Share on LinkedIn'); ?>">
                          <span class="fa fa-linkedin-square"></span><span class="hidden"><?php print t('Share on LinkedIn'); ?></span>
                      </a>
                  </li>
                  <li>
                      <a href="mailto:?subject=<?php print $title; ?>&body=<?php print $url; ?>" target="_blank" title="<?php print t('Email'); ?>">
                          <span class="fa fa-envelope-square"></span><span class="hidden"><?php print t('Email'); ?></span>
                      </a>
                  </li>
              </ul>
          </div>          
        <?php endif; ?>
    </div>
</li>
