<?php

/**
 * @file
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Description of GooglePlusCliFiltersBuilder.
 */
class GooglePlusCliFiltersBuilder {

  protected $filters;

  /**
   *
   */
  public function __construct() {
    $this->filters = new stdClass();
    $this->filters->track = array();
    $this->filters->languages = array('en-GB', 'en-US');
  }

  /**
   * Return the filters object.
   *
   * @return object
   *   An object composed by an array with the terms to search and the supported
   *   languages.
   */
  public function getFilters() {
    $this->filters->track = array_unique($this->filters->track);
    return $this->filters;
  }

  /**
   * Extracts the filters from a drupal G+ node.
   *
   * @param object $node
   *   A drupal node containing the field_track.
   */
  public function addGooglePlusSource($node) {
    if (isset($node->field_twitter_track) && !empty($node->field_twitter_track)) {
      foreach ($node->field_twitter_track['und'] as $search_terms) {
        $this->filters->track[] = $search_terms['safe_value'];
      }
    }
  }

}
