<?php

/**
 * @file
 * Description of ChartRenderFacetFactory.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Builds a JSON document with data for D3 charting library.
 */
class ChartRenderFacetFactory {

  /**
   * Gets the ChartRenderFactory for a chart.
   *
   * @param string $id
   *   An string identifiying the facets group.
   *
   * @return object
   *   An ChartRenderFacet object for the facet group.
   */
  public static function getRender($id) {
    $class = substr($id, 0, strpos($id, '_'));
    $facet = substr($id, strpos($id, '_') + 1);
    switch ($class) {
      case 'treemap':
        return new TreeMapChartRenderFacet($facet);

      case 'tree':
        return new TreeRenderFacet($facet);

      default:
        break;
    }
    return NULL;
  }

}
