<?php

/**
 * @file
 * Description of D3JSONBuilder.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Builds a JSON document with data for D3 charting library.
 */
class D3JSONBuilder {

  private $baseUrl;
  private $lang;
  private $title;

  /**
   *
   */
  public function __construct($base_url, $lang = NULL) {
    $this->baseUrl = $base_url;
    $this->lang = $lang ? '/' . $lang : '';
  }

  public function setTitle($title) {
    $this->title = $title;
  }

  /**
   * Builds a object representing a JSON document with the data for a D3 chart.
   *
   * @param object $facets
   *   The facets information (fq and fields) from Solr query.
   *
   * @return \stdClass
   *   An object representing a JSON document with the data for a D3 chart.
   */
  public function build($facets) {
    $data = new stdClass();
    $data->name = 'GIPO';
    $data->children = array();
    foreach ($facets->fields as $facet_name => $facet_values) {
      $normalized_name = $this->normalizeName($facet_name);
      $facet = new stdClass();
      if (isset($this->title)) {
        $facet->name = $this->title;
      }
      else {
        $facet->name = i18n_taxonomy_vocabulary_name(taxonomy_vocabulary_machine_name_load($normalized_name == 'aspects' ? 'aspect' : $normalized_name));
      }
      $facet->children = array();
      foreach ($facet_values as $name => $value) {
        if (!$this->isActiveFacet($facets->fq, $facet_name, $name)) {
          $translated_term = $this->translateTerm($name);
          $facet->children[] = (object) array(
                'name' => $translated_term == 'Infrastructure and Standardisation' ? 'Infrastructure' : $translated_term,
                'value' => $value,
                'url' => $this->baseUrl . $this->lang . "/search/site/*?f[0]=$normalized_name:$name",
          );
        }
      }
      $data->children[] = $facet;
    }
    return count($facets->fields) == 1 ? $data->children[0] : $data;
  }

  /**
   * Checks if the facet is currently used in the search (is inactive).
   *
   * @param array $fq
   *   The array with the facet query send to the search engine (Solr).
   * @param string $facet
   *   The solr field name of the a facet.
   * @param string $value
   *   The name of the facet.
   *
   * @return bool
   *   True if the facet is not include in the search, false if it is
   */
  protected function isActiveFacet(array $fq, $facet, $value) {
    $normalized_value = $value;
    if (strstr($value, ' ')) {
      $normalized_value = "\"$normalized_value\"";
    }
    return array_search("$facet:$normalized_value", $fq) !== FALSE;
  }

  /**
   * Convert a facet name to human-readable.
   *
   * @param string $facet_name
   *   The facet name field as defined in Solr.
   *
   * @return string
   *   An human readable form of the field
   */
  protected function normalizeName($facet_name) {
    if (strpos($facet_name, 'gipo_') === 0) {
      return substr($facet_name, 5);
    }
    else {
      return $facet_name;
    }
  }

  /**
   * Translates a aspect term to the localized value of the current language.
   *
   * @param string $term
   *   The original (english) term.
   *
   * @return string
   *   A string with the translated term.
   */
  protected function translateTerm($term) {
    if ($term !== NULL && function_exists('i18n_taxonomy_term_name')) {
      global $language;
      $term_name = taxonomy_get_term_by_name($term, 'aspect');
      if (!empty($term_name)) {
        $tid = array_pop($term_name)->tid;
        $translated_terms[] = i18n_taxonomy_term_name(taxonomy_term_load($tid), $language->language);
        return array_pop($translated_terms);
      }
    }
    return $term;
  }

}
