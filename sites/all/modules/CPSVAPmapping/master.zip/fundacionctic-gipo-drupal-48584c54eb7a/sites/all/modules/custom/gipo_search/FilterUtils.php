<?php

/**
 * @file
 * Description of FilterUtils.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Class with utility methods for filters.
 */
class FilterUtils {

  /**
   * @var org\fundacionctic\gipo\TaxonomyTermExtractor
   */
  private $taxonomy_term_extractor;

  /**
   * Public constructor to ensure static use.
   */
  public function __construct(TaxonomyTermExtractor $taxonomy_term_extractor) {
    $this->taxonomy_term_extractor = $taxonomy_term_extractor;
  }

  /**
   *
   * @param object $node_filter
   *   An object of type node filter.
   *
   * @return array
   *   An array with the information neede to apply the filter extracted from
   *   the node.
   */
  public function transformDrupalFilter($node_filter) {
    return array(
      'title' => $node_filter->title,
      'classify_into' => 'gipo_aspects',
      'value' => $this->getTaxonomyTerms($node_filter->field_aspects),
      // 'tags' => array('lorem ipsum'),.
      'field' => array('title', 'description'),
      'field_reg_exp' => $this->getFilterValues($node_filter->field_reg_exp['und']),
    );
  }

  /**
   * Obtain the term name from the term id using an TaxonomyTermExtractor.
   *
   * @param array $field_aspects
   *   The array containing the associated taxonomy terms from the filter node
   *   field field_aspects. Example:
   *   'und' => array(
   *     array(
   *       'tid' => '46',
   *     ),
   *     array(
   *       'tid' => '19',
   *     ),
   *   )
   * 
   * @return array
   *   An array with the title terms.
   */
  private function getTaxonomyTerms(array $field_aspects) {
    $result = array();
    if (isset($field_aspects['und'])) {
      array_walk_recursive($field_aspects['und'], function($value)use(&$result) {
        $term = $this->taxonomy_term_extractor->getTaxonomyTerm($value);
        if ($term !== FALSE) {
            $result[] = $term;
        }
      });
    }
    return $result;
  }

  private function getFilterValues(array $field_reg_exp) {
    $reg_exp = array();
    foreach ($field_reg_exp as $value){
      $reg_exp[] = $value['value'];
    }
    return $reg_exp;
  }

}
