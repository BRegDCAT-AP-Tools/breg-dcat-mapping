<?php

/**
 * @file
 * Description of ExtractLinksPostProcessor.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Extract outgoing links from an item.
 */
class ExtractLinksPostProcessor {

  /**
   * Process an item.
   *
   * Extracts all links to other domains.
   *
   * @param array $vigilancia_item
   *   Modifies vigilancia item tags.
   */
  public function process(&$vigilancia_item) {
    $excluded_domains = array();
    if (isset($vigilancia_item['url'])) {
      $excluded_domains[] = parse_url($vigilancia_item['url'], PHP_URL_HOST);
    }
    if (isset($vigilancia_item['feed'])) {
      $excluded_domains[] = parse_url($vigilancia_item['feed'], PHP_URL_HOST);
    }
    $vigilancia_item['outgoing_links'] = $this->extractLinks($vigilancia_item['description'], $excluded_domains, $vigilancia_item['url']);
  }

  /**
   * Extracts all links from a HTML text not pointing to the $exclude_domain.
   *
   * @param string $description
   *   An HTML text.
   * @param array $excluded_domains
   *   An array of hosts to filter extracted links.
   *
   * @return array
   *    An array with all the links or an empty array.
   */
  private function extractLinks($description, $excluded_domains, $base_url) {
    $outgoing_links = array();
    if (strlen($description) > 0 && $this->isHTML($description)) {
      $dom = new DOMDocument();

      // Parse the HTML. The @ is used to suppress any parsing errors
      // that will be thrown if the $html string isn't valid XHTML.
      @$dom->loadHTML($description);

      // Get all links. You could also use any other tag name here,
      // like 'img' or 'table', to extract other tags.
      $links = $dom->getElementsByTagName('a');

      // Iterate over the extracted links and display their URLs.
      foreach ($links as $link) {
        // Extract the "href" attribute.
        $url = $this->createAbsoluteUrl($link->getAttribute('href'), $base_url);
        if (valid_url($url, TRUE)) {
          $outgoing_domain = parse_url($url, PHP_URL_HOST);
          if (isset($outgoing_domain) && array_search($outgoing_domain, $excluded_domains) === FALSE) {
            $outgoing_links[] = $outgoing_domain;
          }
        }
      }
    }
    return array_unique($outgoing_links);
  }

  /**
   * Checks if a string contains HTML code.
   *
   * @param string $string
   *   The string to check if it contains HTML code.
   *
   * @return bool
   *   True if the string seems to be HTML or false otherwise.
   */
  private function isHTML($string) {
    return preg_match("/\/[a-z]*>/i", $string) != 0;
  }

  function createAbsoluteUrl($url, $base_url) {
    $url = trim($url);
    if (valid_url($url, TRUE)) {
      // Valid absolute url already.
      return $url;
    }

    // Turn relative url into absolute.
    if (valid_url($url, FALSE)) {
      // Produces variables $scheme, $host, $user, $pass, $path, $query and
      // $fragment.
      $parsed_url = parse_url($base_url);
      if ($parsed_url === FALSE) {
        // Invalid $base_url.
        return FALSE;
      }

      $path = isset($parsed_url['path']) ? $parsed_url['path'] : '';
      if (strlen($path) > 0 && substr($path, -1) != '/') {
        // Path ends not with '/', so remove all before previous '/'.
        $path = dirname($path);
      }

      // Adding to the existing path.
      $cparts = array();
      if ($url{0} == '/') {
        $cparts = array_filter(explode("/", $url));
      }
      else {
        // Backtracking from the existing path.
        $path_cparts = array_filter(explode("/", $path));
        $url_cparts = array_filter(explode("/", $url));
        $cparts = array_merge($path_cparts, $url_cparts);
      }

      $remove_parts = 0;
      // Start from behind.
      $reverse_cparts = array_reverse($cparts);
      foreach ($reverse_cparts as $i => &$part) {
        if ($part == '.') {
          $part = NULL;
        }
        elseif ($part == '..') {
          $part = NULL;
          $remove_parts++;
        }
        elseif ($remove_parts > 0) {
          // If the current part isn't "..", and we had ".." before, then delete
          // the part.
          $part = NULL;
          $remove_parts--;
        }
      }
      $cparts = array_filter(array_reverse($reverse_cparts));
      $path = implode("/", $cparts);

      // Build the prefix to the path.
      $absolute_url = '';
      if (isset($parsed_url['scheme'])) {
        $absolute_url = $parsed_url['scheme'] . '://';
      }

      if (isset($parsed_url['user'])) {
        $absolute_url .= $parsed_url['user'];
        if (isset($pass)) {
          $absolute_url .= ':' . $parsed_url['pass'];
        }
        $absolute_url .= '@';
      }
      if (isset($parsed_url['host'])) {
        $absolute_url .= $parsed_url['host'] . '/';
      }

      $absolute_url .= $path;

      if (valid_url($absolute_url, TRUE)) {
        return $absolute_url;
      }
    }
    return FALSE;
  }

}
