<?php
/**
 * @file
 * Zen theme's implementation to display a single Drupal page.
 *
 * Available variables:
 *
 * General utility variables:
 * - $rss: RSS content.
 *
 * @see gipo_export_preprocess_page()
 */
?>
<channel>
<?php print $rss; ?>
</channel>
