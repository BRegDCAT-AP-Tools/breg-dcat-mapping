// jQuery on an empty object, we are going to use this as our queue
var ajaxQueue = jQuery({});

jQuery.ajaxQueue = function (ajaxOpts) {
  // Hold the original complete function
  var oldComplete = ajaxOpts.complete;

  // Queue our ajax request
  ajaxQueue.queue(function (next) {
    // Create a complete callback to invoke the next event in the queue
    ajaxOpts.complete = function () {
      // Invoke the original complete if it was there
      if (oldComplete) {
        oldComplete.apply(this, arguments);
      }

      // Run the next query in the queue
      next();
    };

    // Run the query
    jQuery.ajax(ajaxOpts);
  });
};

function setCookie(c_name, value) {
  var c_value = escape(value);
  document.cookie = c_name + "=" + c_value + "; path=/";
}

function getCookie(c_name) {
  var i, x, y, ARRcookies = document.cookie.split(";");
  for (i = 0; i < ARRcookies.length; i++) {
    x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
    y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
    x = x.replace(/^\s+|\s+$/g, "");
    if (x === c_name) {
      return unescape(y);
    }
  }
}

jQuery(document).ready(function () {
  var language = navigator.languages ? navigator.languages[0] : (navigator.language || navigator.userLanguage);
  language = language.substring(0, 2);
  if (language !== 'en') {
    jQuery("#tags-translate").fadeIn();
  }
  jQuery("#translate-tags-toggle").change(function () {
    setCookie('gipo_tags_translation', jQuery(this).is(":checked"));
    if (jQuery(this).is(":checked")) {
      translate_tags();
    }
  });
  if (getCookie("gipo_tags_translation") === "true") {
    jQuery("#translate-tags-toggle").attr('checked', true);
    translate_tags();
  }
});

function translate_tags() {
  var uniqueTags = [];
  jQuery("*[data-tags]").each(function () {
    var tag = jQuery(this).attr('data-tags');
    // Filter tags so the same tag isn't queried multiple times
    if (jQuery.inArray(tag, uniqueTags) === -1) {
      uniqueTags.push(tag);
    }
  });

  jQuery.each(uniqueTags, function (index, tag) {
    // Queue up an ajax request so we don't flood the service
    jQuery.ajaxQueue({
      url: "/tags-api/translate/" + tag,
      type: "GET",
      success: function (data) {
        var language = navigator.languages ? navigator.languages[0] : (navigator.language || navigator.userLanguage);
        if (language.indexOf('-') !== -1) {
          language = language.substring(0, language.indexOf('-'));
        }
        if (typeof data.translations !== 'undefined' && data.translations[language]) {
          var tag = jQuery('*[data-tags="' + data.name.toLowerCase() + '"]');
          // For all tags adds translation explanation and change style.
          jQuery(tag).attr('title', Drupal.t('Translation of @original_tag.', {'@original_tag': jQuery(tag).data('tags')}));
          jQuery(tag).addClass('translated');
          jQuery(tag).each(function () {
            if (isFirstLetterCapital(jQuery(this).text())) {
              jQuery(this).text(data.translations[language]);
            } else {
              jQuery(this).text(data.translations[language].toLowerCase());
            }
          });
        }
      }
    });
  });
}

function isFirstLetterCapital(word) {
  return word[0] !== word[0].toLowerCase();
}


