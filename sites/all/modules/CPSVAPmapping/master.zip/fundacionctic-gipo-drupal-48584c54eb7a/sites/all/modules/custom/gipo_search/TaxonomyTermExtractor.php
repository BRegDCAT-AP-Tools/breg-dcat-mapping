<?php

/**
 * @file
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Base interface for TaxonomyTermExtractor classes.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */
interface TaxonomyTermExtractor {
  /**
   *
   */
  public function getTaxonomyTerm($term_id);

}

/**
 * TaxonomyTermExtractor based on Drupal function taxonomy_term_load.
 */
class DrupalTaxonomyTermExtractor implements TaxonomyTermExtractor {
  /**
   *
   */
  public function getTaxonomyTerm($term_id) {
    $term = taxonomy_term_load($term_id);
    if ($term !== FALSE) {
      return $term->name;
    }
    return FALSE;
  }

}
