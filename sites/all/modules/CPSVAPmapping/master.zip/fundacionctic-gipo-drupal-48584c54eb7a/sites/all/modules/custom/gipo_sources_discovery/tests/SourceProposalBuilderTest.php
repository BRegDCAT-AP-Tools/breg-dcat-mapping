<?php

require_once dirname(__FILE__) . '/../SourceProposalBuilder.php';

/**
 * SourceProposalBuilder unit tests.
 */
class SourceProposalBuilderTest extends PHPUnit_Framework_TestCase {

  /**
   * @var SourceProposalBuilder
   */
  protected $object;

  /**
   * Sets up create a default SourceProposal object.
   */
  protected function setUp() {
    $this->object = new SourceProposalBuilder([]);
  }

  /**
   * @covers SourceProposalBuilder::build
   */
  public function testBuild() {
    $this->assertEquals('Inicio | Fundación CTIC', $this->object->build('www.fundacionctic.org')->title);
  }

  /**
   * @covers SourceProposalBuilder::build
   */
  public function testStickyFalse() {
    // Test default value is false.
    $this->assertEquals(FALSE, $this->object->build('www.fundacionctic.org')->sticky);
    
    // Test initialized to false.
    $this->object = new SourceProposalBuilder(array('sticky' => FALSE));
    $this->assertEquals(FALSE, $this->object->build('www.fundacionctic.org')->sticky);
  }

  /**
   * @covers SourceProposalBuilder::build
   */
  public function testStickyTrue() {
    $this->object = new SourceProposalBuilder(array('sticky' => TRUE));
    $this->assertEquals(TRUE, $this->object->build('www.fundacionctic.org')->sticky);
  }

  /**
   * @covers SourceProposalBuilder::build
   */
  public function testInvalidURL() {
    $this->assertEquals(FALSE, $this->object->build('www www'));

    $this->assertEquals(FALSE, $this->object->build('noexistenoquenoyno'));
  }

}
