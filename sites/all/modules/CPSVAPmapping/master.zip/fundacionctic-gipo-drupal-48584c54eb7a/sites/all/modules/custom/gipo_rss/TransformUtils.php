<?php

/**
 * @file
 * Helping class for transform between data models.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Transform from Drupal model to decoupled data used by GIPO classes.
 */
class TransformUtils {

  /**
   * Transform an string of tags and equivalents value entries.
   *
   * @param string $string
   *   The entry string.
   *   The string should have this structure tag|equivalent,tag|equivalent,...
   *
   * @return array
   *   An array with the tags as keys and theirs equivalent as value.
   *   (ex. array( tag => equivalent, tag => equivalent,... )
   */
  public static function transformEquivalentTagsStringToArray($string) {
    $equivalent_tags = array();
    $equivalents_list = drupal_explode_tags($string);
    foreach ($equivalents_list as $equivalent_string) {
      $equivalent_pair = explode('|', $equivalent_string);
      $equivalent_tags[$equivalent_pair[0]] = $equivalent_pair[1];
    }
    return $equivalent_tags;
  }

}
