<?php

/**
 * @file
 * Description of SolrAddDocumentJSONBuilder.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Builds a JSON document for Solr update Request.
 */
class SolrAddDocumentJSONBuilder {

  protected $dataItem;

  /**
   * Builds an JSON builder object.
   *
   * @param array $data_item
   *   The new values to update the solr document.
   *   Each key is a solr field and value is the new value of the field (should be another array for multivalue fields).
   */
  public function __construct($data_item) {
    $this->dataItem = $data_item;
  }

  /**
   * Builds a JSON formatted to add a Solr document.
   *
   * @return string
   *   A JSON formatted with the update information.
   */
  public function build() {
    $add_document = new stdClass();
    $add_document->add = new stdClass();
    $add_document->add->doc = $this->createClass();
    return json_encode($add_document);
  }

  /**
   * Creates a object with the update information.
   *
   * @return \stdClass
   *   A object with the structure of a document of Solr.
   */
  private function createClass() {
    $doc = new stdClass();
    $doc->id = $this->dataItem['url'];
    $doc->url = $this->dataItem['url'];
    $doc->title = $this->dataItem['title'];
    $doc->content = $this->sanityzeText($this->dataItem['description']);
    if (isset($this->dataItem['created'])) {
      $doc->tstamp = str_replace('+00:00', 'Z', gmdate('c', $this->dataItem['created']));
    }
    else {
      $doc->tstamp = 'NOW';
    }
    if (isset($this->dataItem['author']) && strlen($this->dataItem['author'])) {
      $doc->author = $this->dataItem['author'];
    }
    if (isset($this->dataItem['feed'])) {
      $doc->feed = $this->dataItem['feed'];
    }
    if (isset($this->dataItem['gipo_aspects']) && count($this->dataItem['gipo_aspects'])) {
      $doc->gipo_aspects = $this->dataItem['gipo_aspects'];
    }
    if (isset($this->dataItem['gipo_type']) && count($this->dataItem['gipo_type'])) {
      $doc->gipo_type = $this->dataItem['gipo_type'];
    }
    if (isset($this->dataItem['world_regions']) && count($this->dataItem['world_regions'])) {
      $doc->gipo_world_regions = $this->dataItem['world_regions'];
    }
    if (isset($this->dataItem['tags']) && count($this->dataItem['tags'])) {
      $doc->tags = $this->dataItem['tags'];
    }
    if (isset($this->dataItem['outgoing_links']) && count($this->dataItem['outgoing_links'])) {
      $doc->outlinks = $this->dataItem['outgoing_links'];
    }
    $doc->gipo_last_updated = 'NOW';
    return $doc;
  }

  /**
   * Removes all HTML code from a text.
   *
   * @param string $text
   *   The text that could be HTML.
   *
   * @return string
   *   A string with all HTML code removed.
   */
  private function sanityzeText($text) {
    // Al texto se le eliminan etiquetas HTML para convertirlo en texto plano y además se codifican caracteres especiales de HTML (<,>,",&).
    // TODO: Buscar opción menos drástica que eliminar todas las comillas dobles.
    $sanityzed_text = html_entity_decode(trim(str_replace('"', '', strip_tags($text))), ENT_NOQUOTES);
    // Como se va a encoder como urlform hay que sustituir los % por %25 ya que los caracteres se sustituyen por %dd.
    $sanityzed_text = str_replace('%', '%25', $sanityzed_text);
    // Se sustituye & por %26 para que no provoque problemas de identificación de parámetro http.
    $sanityzed_text = str_replace('&', '%26', $sanityzed_text);
    return $sanityzed_text;
  }

}
