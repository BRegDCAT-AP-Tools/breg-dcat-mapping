<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TwitterCliFiltersBuilder
 *
 * @author mikunis
 */
class TwitterCliFiltersBuilder {

  protected $filters;

  public function __construct() {
    $this->filters = new stdClass();
    $this->filters->follow = array();
    $this->filters->track = array();
    $this->filters->languages = array();
    $this->filters->location = array();
  }

  public function getFilters() {
    $this->filters->follow = array_unique($this->filters->follow);
    $this->filters->track = array_unique($this->filters->track);
    return $this->filters;
  }

  public function addTwitterSource($node) {
    if (isset($node->field_twitter_follow) && !empty($node->field_twitter_follow)) {
      foreach ($node->field_twitter_follow['und'] as $username) {
        $this->filters->follow[] = $username['safe_value'];
      }
    }
    if (isset($node->field_twitter_track) && !empty($node->field_twitter_track)) {
      foreach ($node->field_twitter_track['und'] as $hashtag) {
        $this->filters->track[] = $hashtag['safe_value'];
      }
    }
  }

}
