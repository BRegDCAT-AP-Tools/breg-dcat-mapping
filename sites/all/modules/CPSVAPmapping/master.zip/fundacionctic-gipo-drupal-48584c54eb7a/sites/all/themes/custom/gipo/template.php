<?php

/**
 * @file
 * Contains theme override functions and preprocess functions for the theme.
 *
 * ABOUT THE TEMPLATE.PHP FILE.
 *
 *   The template.php file is one of the most useful files when creating or
 *   modifying Drupal themes. You can modify or override Drupal's theme
 *   functions, intercept or make additional variables available to your theme,
 *   and create custom PHP logic. For more information, please visit the Theme
 *   Developer's Guide on Drupal.org: http://drupal.org/theme-guide
 *
 * OVERRIDING THEME FUNCTIONS
 *
 *   The Drupal theme system uses special theme functions to generate HTML
 *   output automatically. Often we wish to customize this HTML output. To do
 *   this, we have to override the theme function. You have to first find the
 *   theme function that generates the output, and then "catch" it and modify it
 *   here. The easiest way to do it is to copy the original function in its
 *   entirety and paste it here, changing the prefix from theme_ to gipo_.
 *   For example:
 *
 *     original: theme_breadcrumb()
 *     theme override: gipo_breadcrumb()
 *
 *   where gipo is the name of your sub-theme. For example, the
 *   zen_classic theme would define a zen_classic_breadcrumb() function.
 *
 *   If you would like to override either of the two theme functions used in Zen
 *   core, you should first look at how Zen core implements those functions:
 *     theme_breadcrumbs()      in zen/template.php
 *     theme_menu_local_tasks() in zen/template.php
 *
 *   For more information, please visit the Theme Developer's Guide on
 *   Drupal.org: http://drupal.org/node/173880
 *
 * CREATE OR MODIFY VARIABLES FOR YOUR THEME
 *
 *   Each tpl.php template file has several variables which hold various pieces
 *   of content. You can modify those variables (or add new ones) before they
 *   are used in the template files by using preprocess functions.
 *
 *   This makes THEME_preprocess_HOOK() functions the most powerful functions
 *   available to themers.
 *
 *   It works by having one preprocess function for each template file or its
 *   derivatives (called template suggestions). For example:
 *     THEME_preprocess_page    alters the variables for page.tpl.php
 *     THEME_preprocess_node    alters the variables for node.tpl.php or
 *                              for node-forum.tpl.php
 *     THEME_preprocess_comment alters the variables for comment.tpl.php
 *     THEME_preprocess_block   alters the variables for block.tpl.php
 *
 *   For more information on preprocess functions and template suggestions,
 *   please visit the Theme Developer's Guide on Drupal.org:
 *   http://drupal.org/node/223440
 *   and http://drupal.org/node/190815#template-suggestions
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Override or insert variables into the html templates.
 *
 * @param array $variables
 *   An array of variables to pass to the theme template.
 * @param string $hook
 *   The name of the template being rendered ("html" in this case).
 */
function gipo_preprocess_html(&$variables, $hook) {
  if (!$variables['is_front'] && ($node = menu_get_object())) {

    $variables['theme_hook_suggestions'][] = "0";
    $length = count($variables['theme_hook_suggestions']);
    for ($i = $length - 1; $i > 0; $i--) {
      $variables['theme_hook_suggestions'][$i] = $variables['theme_hook_suggestions'][$i - 1];
    }
    $variables['theme_hook_suggestions'][1] = "html__node__" . $node->type;
  }
  drupal_add_css('http://fonts.googleapis.com/css?family=Montserrat:400,600,700,800,900', array('group' => CSS_THEME));
  // The body tag's classes are controlled by the $classes_array variable. To
  // remove a class from $classes_array, use array_diff().
  // $variables['classes_array'] = array_diff($variables['classes_array'], array('class-to-remove'));.
}

/**
 * Override or insert variables into the page templates.
 *
 * @param array $variables
 *   An array of variables to pass to the theme template.
 * @param string $hook
 *   The name of the template being rendered ("page" in this case).
 */
function gipo_preprocess_page(&$variables, $hook) {
  if (!$variables['is_front'] && array_key_exists('node', $variables) && $variables['node']->type != "") {
    $variables['theme_hook_suggestions'][] = "0";
    $length = count($variables['theme_hook_suggestions']);
    for ($i = $length - 1; $i > 0; $i--) {
      $variables['theme_hook_suggestions'][$i] = $variables['theme_hook_suggestions'][$i - 1];
    }
    $variables['theme_hook_suggestions'][1] = "page__node__" . $variables['node']->type;
  }
}

/**
 * Return a themed breadcrumb trail.
 *
 * @param array $variables
 *   - title: An optional string to be used as a navigational heading to give
 *     context for breadcrumb links to screen-reader users.
 *   - title_attributes_array: Array of HTML attributes for the title. It is
 *     flattened into a string within the theme function.
 *   - breadcrumb: An array containing the breadcrumb links.
 *
 * @return string
 *   A string containing the breadcrumb output.
 */
function gipo_breadcrumb($variables) {
  $breadcrumb = $variables['breadcrumb'];
  // Sources and candidates nodes aren't added to the user menu must add the breadcrumb parts.
  $arguments = explode('/', drupal_lookup_path('alias', current_path()));
  if (count($arguments) > 0 && $arguments[0] == 'sources') {
    $breadcrumb[] = l(t('Sources'), 'sources');
  }
  if (count($arguments) > 1 && $arguments[1] == 'candidates') {
    $breadcrumb[] = l(t('Candidates'), 'sources/candidates');
  }
  // Determine if we are to display the breadcrumb.
  $show_breadcrumb = theme_get_setting('zen_breadcrumb');
  if ($show_breadcrumb == 'yes' || $show_breadcrumb == 'admin' && arg(0) == 'admin') {

    // Optionally get rid of the homepage link.
    $show_breadcrumb_home = theme_get_setting('zen_breadcrumb_home');
    if (!$show_breadcrumb_home) {
      array_shift($breadcrumb);
    }

    // Return the breadcrumb with separators.
    if (!empty($breadcrumb)) {
      $breadcrumb_separator = theme_get_setting('zen_breadcrumb_separator');
      $trailing_separator = $title = '';
      if (theme_get_setting('zen_breadcrumb_title')) {
        $item = menu_get_item();
        if (!empty($item['tab_parent'])) {
          // If we are on a non-default tab, use the tab's title.
          $title = check_plain($item['title']);
        }
        else {
          $title = drupal_get_title();
        }
        if ($title) {
          $trailing_separator = $breadcrumb_separator;
        }
      }
      elseif (theme_get_setting('zen_breadcrumb_trailing')) {
        $trailing_separator = $breadcrumb_separator;
      }

      // Provide a navigational heading to give context for breadcrumb links to
      // screen-reader users.
      if (empty($variables['title'])) {
        $variables['title'] = t('You are here');
      }
      // Unless overridden by a preprocess function, make the heading invisible.
      if (!isset($variables['title_attributes_array']['class'])) {
        $variables['title_attributes_array']['class'][] = 'element-invisible';
      }
      $heading = "";

      foreach ($breadcrumb as $id => $bc) {
        $breadcrumb[$id] = htmlspecialchars_decode($bc);
      }
      $request_path = request_path();
      if (strpos($request_path, 'search/site') === 0) {
        unset($breadcrumb[1]);
      }

      return '<div id="breadcrumb">' . $heading . implode($breadcrumb_separator, $breadcrumb) . $trailing_separator . '<span>' . $title . '</span>' . '</div>';
    }
  }
  // Otherwise, return an empty string.
  return '';
}

/**
 * Override or insert variables into the block templates.
 *
 * @param array $variables
 *   An array of variables to pass to the theme template.
 * @param string $hook
 *   The name of the template being rendered ("block" in this case).
 */
function gipo_preprocess_block(&$variables, $hook) {
  $block = $variables['block'];
  if ($block->module == 'block') {
    $blocks_infos = block_block_info();
    $description = $blocks_infos[$block->delta]['info'];
    $variables['block_html_id'] = 'block-' . $description;

    $variables['theme_hook_suggestions'][] = 'block__' . $description;
  }

  if ($block->module == 'views') {
    $variables['theme_hook_suggestions'][] = "0";
    $length = count($variables['theme_hook_suggestions']);
    $pos = $length - 2;
    for ($i = $length - 1; $i > $pos; $i--) {
      $variables['theme_hook_suggestions'][$i] = $variables['theme_hook_suggestions'][$i - 1];
    }
    // Con esto pongo como sugerencia de plantilla block--views--nombredelavista.
    $variables['theme_hook_suggestions'][$pos] = "block__views__" . substr($block->delta, 0, strpos($block->delta, '-'));
  }
}

/**
 *
 */
function gipo_button($variables) {
  $element = $variables['element'];
  if ($element['#type'] == 'button' && $element['#type'] == 'submit') {
    $element['#attributes']['class'][] = 'btn btn-default';
    return '<button' . drupal_attributes($element['#attributes']) . ' ><span class="fa fa-envelope-o"></span> ' . $element['#value'] . '</button>';
  }
  $element['#attributes']['type'] = 'submit';
  element_set_attributes($element, array('id', 'name', 'value'));

  $element['#attributes']['class'][] = 'form-' . $element['#button_type'];
  if (!empty($element['#attributes']['disabled'])) {
    $element['#attributes']['class'][] = 'form-button-disabled';
  }

  return '<input' . drupal_attributes($element['#attributes']) . ' />';
}

/**
 * Override or insert variables into the region templates.
 *
 * @param array $variables
 *   An array of variables to pass to the theme template.
 * @param string $hook
 *   The name of the template being rendered ("any defined region" in this case).
 */
function gipo_preprocess_region(&$variables, $hook) {
  if (strpos($variables['region'], 'sidebar_second') === 0) {
    // $variables['main_menu'] = i18n_menu_navigation_links(variable_get('menu_main_links_source', 'main-menu'));.
  }
  if (strpos($variables['region'], 'content') === 0 /* && array_key_exists('titleRober', $variables['elements']) */) {
    $variables['title'] = drupal_get_title();
  }
}

/**
 * Returns HTML for a textfield form element.
 *
 * @param array $variables
 *   An associative array containing:
 *   - element: An associative array containing the properties of the element.
 *     Properties used: #title, #value, #description, #size, #maxlength,
 *     #required, #attributes, #autocomplete_path.
 *
 * @ingroup themeable
 */
function gipo_textfield($variables) {
  $element = $variables['element'];
  $element['#attributes']['type'] = 'text';
  element_set_attributes($element, array('id', 'name', 'value', 'size', 'maxlength'));
  _form_set_class($element, array('form-text'));

  $extra = '';
  if ($element['#autocomplete_path'] && drupal_valid_path($element['#autocomplete_path'])) {
    drupal_add_library('system', 'drupal.autocomplete');
    $element['#attributes']['class'][] = 'form-autocomplete';

    $attributes = array();
    $attributes['type'] = 'hidden';
    $attributes['id'] = $element['#attributes']['id'] . '-autocomplete';
    $attributes['value'] = url($element['#autocomplete_path'], array('absolute' => TRUE));
    $attributes['disabled'] = 'disabled';
    $attributes['class'][] = 'autocomplete';
    $extra = '<input' . drupal_attributes($attributes) . ' />';
  }

  if (!empty($element['#required']) && $element['#required'] == TRUE) {
    $element['#attributes']['title'] = t('This field is required.');
  }

  $output = '<input' . drupal_attributes($element['#attributes']) . ' />';

  return $output . $extra;
}

/**
 * Returns HTML for a form.
 *
 * @param array $variables
 *   An associative array containing:
 *   - element: An associative array containing the properties of the element.
 *     Properties used: #action, #method, #attributes, #children.
 *
 * @ingroup themeable
 */
function gipo_form($variables) {
  $element = $variables['element'];
  if ($element['#id'] == 'search-form') {
    // Remove search-form.
    return '';
  }
  else {
    element_set_attributes($element, array('method', 'id'));
    if (empty($element['#attributes']['accept-charset'])) {
      $element['#attributes']['accept-charset'] = "UTF-8";
    }
    // Anonymous DIV to satisfy XHTML compliance.
    return '<form' . drupal_attributes($element['#attributes']) . '><div class="inner-form">' . $element['#children'] . '</div></form>';
  }
}

/**
 *
 */
function gipo_field($variables) {
  $output = '';

  // Render the label, if it's not hidden.
  if (!$variables['label_hidden']) {
    $output .= '<span class="field-label"' . $variables['title_attributes'] . '>' . $variables['label'] . ':&nbsp;</span>';
  }

  // Render the items.
  $output .= '<span class="field-items"' . $variables['content_attributes'] . '>';
  foreach ($variables['items'] as $delta => $item) {
    $classes = 'field-item ' . ($delta % 2 ? 'odd' : 'even');
    $output .= '<span class="' . $classes . '"' . $variables['item_attributes'][$delta] . '>' . drupal_render($item) . '</span>';
  }
  $output .= '</span>';

  // Render the top-level DIV.
  $output = '<div class="' . $variables['classes'] . '"' . $variables['attributes'] . '>' . $output . '</div>';

  return $output;
}

/**
 * Returns HTML for an image with an appropriate icon for the given file.
 *
 * @param array $variables
 *   An associative array containing:
 *   - file: A file object for which to make an icon.
 *   - icon_directory: (optional) A path to a directory of icons to be used for
 *     files. Defaults to the value of the "file_icon_directory" variable.
 *
 * @ingroup themeable
 */
function gipo_file_icon($variables) {
  $file = $variables['file'];
  $icon_directory = $variables['icon_directory'];

  $mime = check_plain($file->filemime);

  $tipo_documento = substr($mime, strpos($mime, '/') + 1);

  $icon_url = file_icon_url($file, $icon_directory);
  return '<img class="file-icon" alt="' . t(strtoupper($tipo_documento) . ' document') . '" src="' . $icon_url . '" />';
}

/**
 * Implementation of hook_form_alter().
 */
function gipo_form_alter(&$form, &$form_state, $form_id) {
  if ($form_id == 'search_block_form') {
    unset($form['search_block_form']['#title']);

    $form['search_block_form']['#title_display'] = 'invisible';
    $form_default = t('Search');
    $form['search_block_form']['#default_value'] = $form_default;
    $form['actions']['submit'] = array('#type' => 'image_button', '#src' => base_path() . path_to_theme() . '/images/search-button.png');

    $form['search_block_form']['#attributes'] = array('onblur' => "if (this.value == '') {this.value = '{$form_default}';}", 'onfocus' => "if (this.value == '{$form_default}') {this.value = '';}");
  }
  if ($form_id == 'user_login_block') {
    unset($form['links']);
  }
  if ($form_id == 'custom_search_blocks_form_1') {
    $form['custom_search_blocks_form_1']['#description'] = t('Press the Enter or Return key to initiate the search');
  }
  if ($form_id == 'contact_site_form') {
    $form['actions']['submit'] = array(
      '#type' => 'button',
      '#button_type' => 'submit',
      '#value' => t('Send message'),
    );
  }
}

/**
 * Themes field collection items printed using the field_collection_view formatter.
 */
function gipo_field_collection_view($variables) {
  $element = $variables['element'];
  return $element['#children'];
}

/**
 *
 */
function gipo_rdf_template_variable_wrapper($variables) {
  // print_r($variables);
  $output = $variables['content'];
  if (!empty($output) && !empty($variables['attributes'])) {
    $attributes = drupal_attributes($variables['attributes']);
    $output = $variables['inline'] ? "<span$attributes>$output</span>" : "<div$attributes>$output</div>";
  }
  return $output;
}

/**
 * Theme preprocess function for theme_field() and field.tpl.php.
 *
 * @see theme_field()
 * @see field.tpl.php
 */
function gipo_preprocess_field(&$variables, $hook) {
  $element = $variables['element'];
  // Add specific suggestions that can override the default implementation.
  $variables['theme_hook_suggestions'] = array(
    'field__' . $element['#field_type'],
    'field__' . $element['#field_name'],
    'field__' . $element['#bundle'],
    'field__' . $element['#view_mode'],
    // Añadido.
    'field__' . $element['#bundle'] . '__' . $element['#view_mode'],
    // Añadido.
    'field__' . $element['#field_name'] . '__' . $element['#bundle'],
    'field__' . $element['#field_name'] . '__' . $element['#view_mode'],
    // Añadido.
    'field__' . $element['#field_name'] . '__' . $element['#bundle'] . '__' . $element['#view_mode'],
      // Añadido.
  );
}

/**
 * Override of theme_tablesort_indicator().
 *
 * Use our own image versions, so they show up as black and not gray on gray.
 */
function gipo_tablesort_indicator($variables) {
  $style = $variables['style'];
  $theme_path = drupal_get_path('theme', 'gipo');
  if ($style == 'asc') {
    return theme('image', array(
      'path' => $theme_path . '/images/arrow-asc.png',
      'alt' => t('sort ascending'),
      'width' => 13,
      'height' => 13,
      'title' => t('sort ascending'),
        )
    );
  }
  else {
    return theme('image', array(
      'path' => $theme_path . '/images/arrow-desc.png',
      'alt' => t('sort descending'),
      'width' => 13,
      'height' => 13,
      'title' => t('sort descending'),
        )
    );
  }
}

/**
 *
 */
function gipo_image($variables) {
  $attributes = $variables['attributes'];
  $attributes['src'] = file_create_url($variables['path']);

  $attributes['src'] = str_replace($GLOBALS['base_url'], '', $attributes['src']);

  foreach (array('width', 'height', 'alt', 'title') as $key) {

    if (isset($variables[$key])) {
      $attributes[$key] = $variables[$key];
    }
  }

  return '<img' . drupal_attributes($attributes) . ' />';
}

/**
 *
 */
function gipo_date_combo($variables) {
  return theme('form_element', $variables);
}

/**
 * Adds total results variable.
 * @param array $variables
 */
function gipo_preprocess_search_results(&$variables) {
  drupal_add_library('system', 'jquery.ui');
  drupal_add_js("jQuery('a.dropdown-toggle').next().hide();"
      . "jQuery('a.dropdown-toggle').click(function(evt) {"
      . "jQuery(evt.target).parent().next().toggle();"
      . "return false;"
      . "});", array('type' => 'inline', 'scope' => 'footer'));
  if (isset($variables['response'])) {
    $variables['total_results'] = $variables['response']->response->numFound;
  }
}

/**
 * Implements template_preprocess_search_result().
 *
 * Process variables for search-results.tpl.php.
 *
 * The $variables array contains the following arguments:
 * - $results: Search results array.
 * - $module: Module the search results came from (module implementing
 *   hook_search_info()).
 *
 * @see search-results.tpl.php
 */
function gipo_preprocess_search_result(&$variables) {
  if (isset($variables['result']['tags'])) {
    $variables['tags'] = theme('result_solr_facet', array(
      'items' => $variables['result']['tags'],
      'facet class' => 'tags',
      'icon class' => '',
        )
    );
  }
  if (isset($variables['result']['gipo_aspects'])) {
    $variables['gipo_aspects'] = theme('result_solr_facet', array(
      'items' => $variables['result']['gipo_aspects'],
      'facet class' => 'aspects',
      'icon class' => '',
        )
    );
  }
  if (isset($variables['result']['gipo_world_regions'])) {
    $variables['gipo_world_regions'] = theme('result_solr_facet', array(
      'items' => $variables['result']['gipo_world_regions'],
      'facet class' => 'world_regions',
      'icon class' => '',
        )
    );
  }
  if (isset($variables['result']['gipo_type'])) {
    $variables['gipo_type'] = theme('result_solr_facet', array(
      'items' => $variables['result']['gipo_type'],
      'facet class' => 'type',
      'icon class' => '',
        )
    );
  }
  if (isset($variables['result']['created'])) {
    $variables['created'] = $variables['result']['created'];
    $variables['datetime'] = date('Y-m-d', $variables['created']);
    $variables['month_year'] = date('M y', $variables['created']);
    $variables['day'] = date('d', $variables['created']);
  }
  if (isset($variables['result']['redirect_link'])) {
    $variables['redirect_link'] = $variables['result']['redirect_link'];
  }
  else {
    $variables['redirect_link'] = '';
  }
  if (isset($variables['result']['fields']['source_title'])) {
    $variables['source'] = l($variables['result']['fields']['source_title'], 'node/' . $variables['result']['fields']['source_nid'], array(
      'attributes' => array('class' => array('source')),
    ));
  }
  else {
    $variables['source'] = FALSE;
  }
}

/**
 * Formats the tstamp field from a Solr document.
 *
 * @param array $variables
 *   Array with the model.
 *
 * @return string
 *   A date formated string.
 */
function gipo_views_view_field__tstamp($variables) {
  $date = DateTimeImmutable::createFromFormat("Y-m-d\TH:i:s.u\Z", $variables['output']);
  return date_format($date, 'Y-m-d');
}

/**
 * Implements hook_item_list().
 */
function gipo_item_list($variables) {
  if (isset($variables['attributes']['id']) && $variables['attributes']['id'] == 'facetapi-facet-apachesolrgipo-search-block-gipo-aspects') {
    //$variables['attributes']['class'][] = 'fa-ul';
  }
  return theme_item_list($variables);
}

/**
 * Implements template_preprocess_comment().
 */
function gipo_preprocess_comment(&$variables) {
  $variables['subject'] = $variables['comment']->subject;

  $uri = entity_uri('comment', $variables['comment']);
  $uri['options'] += array(
    'attributes' => array(
      'class' => array('permalink'),
      'title' => t('Permalink'),
      'rel' => 'bookmark',
    ),
    'html' => TRUE,
  );
  $variables['permalink'] = l(t('<span class="fa fa-link fa-flip-horizontal"></span> <span class="element-invisible">Permalink</span>'), $uri['path'], $uri['options']);
}

/**
 * Returns HTML for an active facet item.
 *
 * @param $variables
 *   An associative array containing the keys 'text', 'path', and 'options'. See
 *   the l() function for information about these variables.
 *
 * @see l()
 *
 * @ingroup themeable
 */
function gipo_facetapi_link_active($variables) {
  // Sanitizes the link text if necessary.
  $sanitize = empty($variables['options']['html']);
  $link_text = ($sanitize) ? check_plain($variables['text']) : $variables['text'];

  // Theme function variables fro accessible markup.
  // @see http://drupal.org/node/1316580
  $accessible_vars = array(
    'text' => $variables['text'],
    'active' => TRUE,
  );

  // Builds link, passes through t() which gives us the ability to change the
  // position of the widget on a per-language basis.
  $replacements = array(
    '!facetapi_deactivate_widget' => theme('facetapi_deactivate_widget', $variables),
    '!facetapi_accessible_markup' => theme('facetapi_accessible_markup', $accessible_vars),
    '!link_text' => format_string("<span data-tags='@data_tag'>!link_text</span>", array('@data_tag' => strtolower($link_text), '!link_text' => $link_text)),
  );
  $variables['text'] = t('!facetapi_deactivate_widget !link_text !facetapi_accessible_markup', $replacements);
  $variables['options']['html'] = TRUE;
  $variables['options']['attributes']['title'] = t('Remove @text filter', array('@text' => $accessible_vars['text']));
  return theme_link($variables);
}

/**
 * Returns HTML for an inactive facet item.
 *
 * @param array $variables
 *   An associative array containing the keys 'text', 'path', 'options', and
 *   'count'. See the l() and theme_facetapi_count() functions for information
 *   about these variables.
 *
 * @ingroup themeable
 */
function gipo_facetapi_link_inactive($variables) {
  // Builds accessible markup.
  // @see http://drupal.org/node/1316580
  $accessible_vars = array(
    'text' => $variables['text'],
    'active' => FALSE,
  );
  $accessible_markup = theme('facetapi_accessible_markup', $accessible_vars);

  // Sanitizes the link text if necessary.
  $sanitize = empty($variables['options']['html']);
  // The attribute !data_tag will be printed as is and no escaping is needed.
  $template = "<span !data_tag>@tag_name</span>";
  $tag_name = ($sanitize) ? check_plain($variables['text']) : $variables['text'];
  $data_tag = '';
  if (str_word_count($tag_name) < 4) {
    $data_tag = strtolower("data-tags='$tag_name'");
  }
  $variables['text'] = format_string($template, array('@tag_name' => $tag_name, '!data_tag' => $data_tag));
  // Adds count to link if one was passed.
  if (isset($variables['count'])) {
    $variables['text'] .= ' ' . theme('facetapi_count', $variables);
  }

  // Resets link text, sets to options to HTML since we already sanitized the
  // link text and are providing additional markup for accessibility.
  $variables['text'] .= $accessible_markup;
  $variables['options']['html'] = TRUE;
  $variables['options']['attributes']['title'] = t('Apply @text filter', array('@text' => $accessible_vars['text']));
  return theme_link($variables);
}

/**
 * Returns HTML for the deactivation widget.
 *
 * @param array $variables
 *   An associative array containing the keys 'text', 'path', and 'options'. See
 *   the l() function for information about these variables.
 *
 * @see l()
 * @see theme_facetapi_link_active()
 *
 * @ingroup themable
 */
function gipo_facetapi_deactivate_widget($variables) {
  return '(&mdash;)';
}
