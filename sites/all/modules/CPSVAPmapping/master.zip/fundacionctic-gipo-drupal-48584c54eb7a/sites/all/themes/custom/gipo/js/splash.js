(function () {

  function fromSameOrigin() {
    return (document.referrer.indexOf(location.protocol + "//" + location.host) === 0);
  }

  function setCookie(c_name, value, exdays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + exdays);
    var c_value = escape(value) + ((exdays == null) ? "" : "; expires=" + exdate.toUTCString());
    document.cookie = c_name + "=" + c_value;
  }

  function getCookie(c_name) {
    var i, x, y, ARRcookies = document.cookie.split(";");
    for (i = 0; i < ARRcookies.length; i++) {
      x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
      y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
      x = x.replace(/^\s+|\s+$/g, "");
      if (x == c_name) {
        return unescape(y);
      }
    }
  }

  var splashOverlay = document.getElementById("splash-overlay");
  var splashWrapper = document.getElementById("splash-wrapper");
  var splashCloseLink = document.getElementById("splash-close-link");
  var exploreLink = document.getElementById("sp-explore-link");
  var exploreLi = document.getElementById("sp-explore-li");
  var visualizeLi = document.getElementById("sp-visualize-li");
  var buildLi = document.getElementById("sp-build-li");
  var check = document.getElementById("sp-not-show-check");
  var getStartedLink = document.getElementById("get-started");
  var moreInfoLink = document.getElementById("more-info-link");

  var closeSplash = function () {
    splashOverlay.style.display = "none";
    splashWrapper.style.display = "none";
    splashWrapper.setAttribute("class", "sp-up");
  };

  var showSplash = function (check) {
    splashOverlay.style.display = "block";
    splashWrapper.style.display = "block";
    splashWrapper.setAttribute("class", "sp-down");

    var checkContainer = document.getElementById("sp-not-show");
    if (check) {
      checkContainer.style.display = "block";
    } else {
      checkContainer.style.display = "none";
    }
  };

  closeSplash();

  if (getCookie("gipo-splash") == "hide") {
    check.checked = true;
    closeSplash();
  } else if (!fromSameOrigin()) {
    showSplash(true);
  }

  splashCloseLink.addEventListener("click", closeSplash);
  exploreLink.addEventListener("click", closeSplash);
  exploreLi.addEventListener("click", closeSplash);

  getStartedLink.addEventListener("click", function () {
    showSplash(false);
  });

  visualizeLi.addEventListener("click", function () {
    window.location = "http://observatory.giponet.org/dashboard";
  });
  buildLi.addEventListener("click", function () {
    window.location = "http://observatory.giponet.org/open-data";
  });

  var handleCheck = function (cb) {
    if (cb.checked) {
      setCookie("gipo-splash", "hide", 1000);
    } else {
      setCookie("gipo-splash", "show", 1000);
    }
  };

  check.addEventListener("click", function () {
    handleCheck(this);
  });

  moreInfoLink.addEventListener("click", function () {
    var moreInfoContainer = document.getElementById("more-info-container");
    if (moreInfoContainer.style.display == "block") {
      moreInfoContainer.style.display = "none";
    } else {
      moreInfoContainer.style.display = "block";
    }
  });


})();