<?php
/**
 * @file
 * Default theme implementation for displaying search results.
 *
 * This template collects each invocation of theme_search_result(). This and
 * the child template are dependent to one another sharing the markup for
 * definition lists.
 *
 * Note that modules may implement their own search type and theme function
 * completely bypassing this template.
 *
 * Available variables:
 * - $search_results: All results as it is rendered through
 *   search-result.tpl.php
 * - $module: The machine-readable name of the module (tab) being searched, such
 *   as "node" or "user".
 *
 *
 * @see template_preprocess_search_results()
 */
?>
<?php if ($search_results): ?>
  <?php if ($module != 'gipo_search_latest_items'): ?>
    <h2 class="search-total"><?php print t('Results') ?> <span class="total_results">(<?php print number_format($total_results); ?>)</span></h2>
  <?php else: ?>
    <div id="tags-translate" style="float: none" class="switch">          
        <label for="translate-tags-toggle" class="switch-light switch-candy-blue">
            <input id="translate-tags-toggle" type="checkbox">
            <strong>
                <?php print t('Automatic tags translation') ?>
            </strong>
            <span id="info">
                <span class="fa fa-question-circle" title="<?php print t('If your local language is not supported by our system, many tags can be automatically translated by enabling this option.'); ?>"></span>
                <span class="element-invisible"><?php print t('If your local language is not supported by our system, many tags can be automatically translated by enabling this option.'); ?></span>
            </span>
            <span id="translate-tags-on_off" aria-hidden="true">
                <span>Off</span>
                <span>On</span>
                <a></a>
            </span>
        </label>
    </div>
  <?php endif; ?>
  <ul class="search-results <?php print $module; ?>-results">
      <?php print $search_results; ?>
  </ul>
  <?php if ($module != 'gipo_search_latest_items'): ?>
    <?php print $pager; ?>
  <?php endif; ?>
<?php else : ?>
  <h2><?php print t('Your search yielded no results'); ?></h2>
  <?php print search_help('search#noresults', drupal_help_arg()); ?>
<?php endif; ?>
