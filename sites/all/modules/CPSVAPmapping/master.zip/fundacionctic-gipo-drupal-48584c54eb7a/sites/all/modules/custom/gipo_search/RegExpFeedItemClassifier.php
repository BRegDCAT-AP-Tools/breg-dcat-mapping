<?php

/**
 * @file
 * Description of RegExpFeedItemClassifier.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Classifies an item incoming from a rss feed using regexp.
 */
class RegExpFeedItemClassifier {

  private $filters;

  /**
   * Builds an RegExpFeedItemClassifier object.
   *
   * @param array $filters
   *   An array with all the filters to check.
   */
  public function __construct($filters) {
    $this->filters = $filters;
  }

  /**
   * Classifies an item.
   *
   * Assigns the taxonomy and tags associated to an regularexpression if it
   * matches the title or description of the item.
   *
   * @param array $item
   *   The new values to update the solr document.
   *   Each key is a solr field and value is the new value of the field (should
   *    be another array for multivalue fields).
   *
   * @return string
   *   A JSON formatted with the update information.
   */
  public function classify($item) {
    set_time_limit(200);

    $checked_item = $this->initItem($item);
    $classified_item = $this->applyFilters($checked_item);

    return $classified_item;
  }

  /**
   * Initializes the provided item.
   *
   * @param array $item
   *   An item incoming from a source.
   *
   * @return array
   *   An array with all missing required fields initialized to blank ('' or an
   *   empty array)
   */
  private function initItem($item) {
    if (!isset($item['url'])) {
      $item['url'] = '';
    }
    if (!isset($item['title'])) {
      $item['title'] = '';
    }
    if (!isset($item['description'])) {
      $item['description'] = '';
    }
    if (!isset($item['gipo_aspects'])) {
      $item['gipo_aspects'] = array();
    }
    if (!isset($item['tags'])) {
      $item['tags'] = array();
    }

    return $item;
  }

  /**
   * Apply filters.
   *
   * @param array $item
   *   An item incoming from a source (RSS, webcrawl, Twitter...).
   *
   * @return array
   *   The aspects, type and tags for each matched filter.
   */
  private function applyFilters($item) {
    $result = array(
      'gipo_aspects' => array(),
      'gipo_type' => array(),
      'tags' => array(),
    );
    $result['gipo_aspects'] = $item['gipo_aspects'];
    $result['tags'] = array_merge($result['tags'], $item['tags']);
    foreach ($this->filters as $filter) {
      $min_ocurrences = isset($filter['min_ocurrences']) ? $filter['min_ocurrences'] : 0;
      foreach ($filter['field'] as $field) {
        foreach ($filter['field_reg_exp'] as $reg_exp) {
          if (preg_match($reg_exp, $item[$field])) {
            $result[$filter['classify_into']] = array_merge($result[$filter['classify_into']], $filter['value']);
            if (isset($filter['tags'])) {
              $result['tags'] = array_merge($result['tags'], $filter['tags']);
            }
            // Stop at the first match to avoid duplicate $filter['value'] and
            // $filter['tags'] values.
            break;
          }
        }
      }
    }
    if (isset($item['url'])) {
      if (preg_match('/\.youtube\./i', $item['url']) || preg_match('/y2u\.be/i', $item['url'])) {
        $result['gipo_type'] = array('MovingImage');
      }
      else {
        $result['gipo_type'] = array('Text');
      }
    }
    else {
      $result['gipo_type'] = array('Text');
    }
    $result['gipo_aspects'] = array_values(array_unique($result['gipo_aspects']));
    $result['gipo_type'] = array_values(array_unique($result['gipo_type']));
    $result['tags'] = array_values(array_unique($result['tags']));

    return $result;
  }

}
