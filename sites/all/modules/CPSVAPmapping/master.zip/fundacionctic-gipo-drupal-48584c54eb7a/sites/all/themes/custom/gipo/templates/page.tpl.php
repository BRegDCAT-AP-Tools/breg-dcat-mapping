<?php
/**
 * @file
 * Zen theme's implementation to display a single Drupal page.
 *
 * Available variables:
 *
 * General utility variables:
 * - $base_path: The base URL path of the Drupal installation. At the very
 *   least, this will always default to /.
 * - $directory: The directory the template is located in, e.g. modules/system
 *   or themes/garland.
 * - $is_front: TRUE if the current page is the front page.
 * - $logged_in: TRUE if the user is registered and signed in.
 * - $is_admin: TRUE if the user has permission to access administration pages.
 *
 * Site identity:
 * - $front_page: The URL of the front page. Use this instead of $base_path,
 *   when linking to the front page. This includes the language domain or
 *   prefix.
 * - $logo: The path to the logo image, as defined in theme configuration.
 * - $site_name: The name of the site, empty when display has been disabled
 *   in theme settings.
 * - $site_slogan: The slogan of the site, empty when display has been disabled
 *   in theme settings.
 *
 * Navigation:
 * - $main_menu (array): An array containing the Main menu links for the
 *   site, if they have been configured.
 * - $secondary_menu (array): An array containing the Secondary menu links for
 *   the site, if they have been configured.
 * - $secondary_menu_heading: The title of the menu used by the secondary links.
 * - $breadcrumb: The breadcrumb trail for the current page.
 *
 * Page content (in order of occurrence in the default page.tpl.php):
 * - $title_prefix (array): An array containing additional output populated by
 *   modules, intended to be displayed in front of the main title tag that
 *   appears in the template.
 * - $title: The page title, for use in the actual HTML content.
 * - $title_suffix (array): An array containing additional output populated by
 *   modules, intended to be displayed after the main title tag that appears in
 *   the template.
 * - $messages: HTML for status and error messages. Should be displayed
 *   prominently.
 * - $tabs (array): Tabs linking to any sub-pages beneath the current page
 *   (e.g., the view and edit tabs when displaying a node).
 * - $action_links (array): Actions local to the page, such as 'Add menu' on the
 *   menu administration interface.
 * - $feed_icons: A string of all feed icons for the current page.
 * - $node: The node object, if there is an automatically-loaded node
 *   associated with the page, and the node ID is the second argument
 *   in the page's path (e.g. node/12345 and node/12345/revisions, but not
 *   comment/reply/12345).
 *
 * Regions:
 * - $page['help']: Dynamic help text, mostly for admin pages.
 * - $page['highlighted']: Items for the highlighted content region.
 * - $page['content']: The main content of the current page.
 * - $page['sidebar_first']: Items for the first sidebar.
 * - $page['sidebar_second']: Items for the second sidebar.
 * - $page['header']: Items for the header region.
 * - $page['footer']: Items for the footer region.
 * - $page['bottom']: Items to appear at the bottom of the page below the footer.
 *
 * @see template_preprocess()
 * @see template_preprocess_page()
 * @see zen_preprocess_page()
 * @see template_process()
 */
?>

  <?php print render($page['highlighted']); ?>

  <div id="header"><div class="section clearfix">
    <?php if ($logo): ?>
      <h1><a href="<?php print $front_page; ?>" title="<?php print t('Go to home page'); ?>" rel="home" id="logo"><img src="<?php print $logo; ?>" alt="<?php print t('GIPO. Global Internet Policy Observatory'); ?>" /></a></h1>
    <?php endif; ?>

    <div id="get-started-wrapper"><a id="get-started" href="#"><?php print t('Getting started')?></a></div>
    <?php print theme('links__system_secondary_menu', array(
      'links' => $secondary_menu,
      'attributes' => array(
        'id' => 'secondary-menu',
        'class' => array('links', 'inline', 'clearfix'),
      ),
      'heading' => array(
        'text' => $secondary_menu_heading,
        'level' => 'h2',
        'class' => array('element-invisible'),
      ),
    )); ?>
    
    <?php print render($page['header']); ?>        
  </div></div><!-- /.section, /#header -->

    <?php if ($page['navigation'] || $main_menu && !$front_page): ?>
      <div id="navigation"><div class="section clearfix">
        <?php print render($page['navigation']); ?>
      </div></div><!-- /.section, /#navigation -->
    <?php endif; ?>

    <?php if ($page['carrusel']): ?>
      <div id="carrusel"><div class="section clearfix">
        <?php print render($page['carrusel']); ?>
      </div></div><!-- /.section, /#carrusel -->
    <?php endif; ?>


    <?php if ($breadcrumb): ?>
      <div id="contenedor-breadcrumb">
        <?php print $breadcrumb; ?>
      </div>
    <?php endif; ?>

  <?php if ($tabs = render($tabs)): ?>
    <div class="tabs"><?php print $tabs; ?></div>
  <?php endif; ?>
  <?php print $messages; ?>

    <div id="main" class="clearfix<?php // if ($main_menu || $page['navigation']) { print ' with-navigation'; } ?>">

      <?php if ($title && !$front_page): ?>
        <h2 class="title" id="page-title"><?php print $title; ?></h2>
      <?php endif; ?>

      <?php print render($page['help']); ?>
      <?php if ($action_links): ?>
        <ul class="action-links"><?php print render($action_links); ?></ul>
      <?php endif; ?>
        
      <?php print render($page['sidebar_second']); ?>
      
      <?php print render($page['content']); ?>
        
      <!-- Splash Overlay -->
      <div id="splash-overlay">&nbsp;</div>
      <!-- Splash Wrapper -->

      <div class="sp-up" id="splash-wrapper">
        <div class="fadeMe" id="splash">
            <a title="Explore" href="#" id="splash-close-link">
              <img alt="Close" src="/sites/all/themes/custom/gipo/images/icon_close_white_16.png">
            </a>
            <div>
                <h1>
                    Getting Started
                </h1>
            </div>
            <div>
                <p id="sp-intro">Welcome to your GIPO home page. From here you can do many things.</p>
                <ul>
                  <li id="sp-explore-li">
                    <div>
                      <h2 class="sp-option-header">Explore</h2>
                      <a id="sp-explore-link" title="Explore" href="http://observatory.giponet.org/">
                          <img alt="Explore" src="/sites/all/themes/custom/gipo/images/GP-GS01.png"></a>
                      <p class="sp-option-description">
                          Search information on Internet policy developments and decisions
                      </p>
                    </div>
                  </li>
                  <li id="sp-visualize-li">
                    <div>
                      <h2 class="sp-option-header">Visualize</h2>
                      <a title="Visualize" href="http://observatory.giponet.org/dashboard">
                          <img alt="Visualize" src="/sites/all/themes/custom/gipo/images/GP-GS02.png"></a>
                      <p class="sp-option-description">
                          Discover and analyze trends with your own graphical dashboard
                      </p>
                    </div>
                  </li>
                  <li id="sp-build-li">
                    <div>
                      <h2 class="sp-option-header">Build</h2>
                      <a title="Build" href="http://observatory.giponet.org/open-data">
                          <img alt="Build" src="/sites/all/themes/custom/gipo/images/GP-GS03.png"></a>
                      <p class="sp-option-description">
                          Get useful data for your website and develop apps using the API
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            <div id="sp-not-show">
                <label for="sp-not-show-check"><input type="checkbox" id="sp-not-show-check">&nbsp;Do not show again (accept cookies)</label>
                <a href="#" id="more-info-link"><small>More info</small></a>
                <div id="more-info-container">
					GIPO Tool uses cookies only to remember your browsing preferences 
					(disable this <em>"Getting started"</em> dialog box). We do not record any other information nor use any third party cookies. 
					By enabling the <em>"Do not show again"</em> option you are accepting this cookies policy.
                </div>
            </div>
          </div>
        </div>
    </div><!-- /#main -->

  </div><!-- #subcontenedor -->
</div><!-- #contenedor -->

<?php print render($page['footer']); ?>


<?php print render($page['bottom']); ?>

<!-- Splash JS -->
<script src="/sites/all/themes/custom/gipo/js/splash.js"></script>