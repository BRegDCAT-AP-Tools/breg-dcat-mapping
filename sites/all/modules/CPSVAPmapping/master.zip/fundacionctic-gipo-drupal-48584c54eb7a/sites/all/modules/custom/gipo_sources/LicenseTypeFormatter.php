<?php

/**
 * @file
 * Description of LicenseTypeFormatter.
 *
 * @author mikunis
 */

/**
 * Formatter for License Type field of Source content type.
 */
class LicenseTypeFormatter {

  protected $url;

  /**
   * Builds an license type formatter for the license pointed by the url.
   *
   * @param string $url
   *   An url to the license page or special value '_custom_'.
   */
  public function __construct($url) {
    $this->url = $url;
  }

  /**
   * Gets the type (CC, custom, unknown) of the license.
   *
   * @return string
   *   The type (identifier) of this license
   */
  public function extractLicenseType() {
    if ($this->url == '_custom_') {
      return 'custom';
    }
    else {
      $url_ending = substr($this->url, -4);
      if ($url_ending == '/4.0') {
        $last_slash = strrpos($this->url, '/', -5);
        $len = strlen($this->url);
        $value = substr($this->url, $last_slash + 1, $len - $last_slash - 5);
        return $value;
      }
    }
    return 'unknown';
  }

}
