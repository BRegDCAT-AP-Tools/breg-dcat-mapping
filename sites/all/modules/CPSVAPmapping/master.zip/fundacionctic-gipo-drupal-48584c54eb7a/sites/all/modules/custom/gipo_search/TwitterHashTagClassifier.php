<?php

/**
 * @file
 * Description of TwitterHashTagClassifier.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Classifies an item incoming from a rss feed using regexp.
 */
class TwitterHashTagClassifier {

  /**
   * Classifies an item assigning the taxonomy and tags associated to an regular
   *  expression if it matches the title or description of the item.
   *
   * @param array $item
   *   The new values to update the solr document.
   *   Each key is a solr field and value is the new value of the field (should
   *    be another array for multivalue fields).
   *
   * @return string
   *   A JSON formatted with the update information.
   */
  public function classify($item) {
    $checked_item = $this->checkItem($item);
    $classified_item = $this->extractTags($checked_item);

    return $classified_item;
  }

  /**
   * @param array $item
   *
   * @return array
   *   An array with all missing required fields initialized to blank ('' or an
   *   empty array)
   */
  private function checkItem($item) {
    if (!isset($item['tags'])) {
      $item['tags'] = array();
    }

    return $item;
  }

  /**
   * Extracts tags from twitter HashTags.
   */
  private function extractTags($item) {
    $result = array(
      'tags' => array(),
    );
    if (isset($item['title'])) {
      $matches = array();
      if (preg_match_all('/#(\w+)/i', $item['title'], $matches)) {
        // The 0-position of the array contains the matching whereas the 1-position contains the group content.
        // In plain english: Each 0 subarray element contains the # character whereas the 1 subarray element doesn't.
        foreach ($matches[1] as $match) {
          $result['tags'][] = $this->convertFromCamelCase($match);
        }
      }
    }

    return $result;
  }

  /**
   * Converts camelCase string to have spaces between each.
   *
   * @param $camel_case_string
   *
   * @return string
   */
  private function convertFromCamelCase($camel_case_string) {
    $words = preg_split('/(?<=[a-z])(?=[A-Z0-9])/x', $camel_case_string);
    return join($words, " ");
  }

}
