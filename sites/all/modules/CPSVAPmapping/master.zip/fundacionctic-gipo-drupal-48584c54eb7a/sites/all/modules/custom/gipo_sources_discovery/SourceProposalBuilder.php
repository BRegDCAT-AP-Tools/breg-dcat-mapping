<?php

/**
 * @file
 * Description of Candidate to Source Builder.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * Builds a source proposal item.
 */
class SourceProposalBuilder {

  /**
   * Errors array init....
   *
   * @var array
   */
  public $errors = array();
  public $outlinks;

  private $isUserCandidate;
  private $workflow;

  /**
   * Builds an SourceProposalBuilder object.
   *
   * @param array $params
   *   An array with the parameters.
   */
  public function __construct($params) {
    if (array_key_exists('user_candidate', $params)) {
      $this->isUserCandidate = boolval($params['user_candidate']);
    }
    else {
      $this->isUserCandidate = FALSE;
    }
    if (array_key_exists('outlinks', $params)) {
      $this->outlinks = intval($params['outlinks']);
    }
    else {
      $this->outlinks = 0;
    }
    if (array_key_exists('workflow', $params)) {
      $this->workflow = intval($params['workflow']);
    }
    else {
      $this->workflow = 1;
    }
  }

  /**
   * Build a new source proposal.
   *
   * @param array $candidate
   *   The info of the new source candidate.
   *
   * @return object
   *   A object structured like the drupal source_proposal node type.
   */
  public function build($candidate) {
    $node = new stdClass();
    $node->type = 'source_proposal';
    $node->is_new = TRUE;
    $node->status = TRUE;
    $node->sticky = $this->isUserCandidate;

    $node->uid = 1;
    $node->language = LANGUAGE_NONE;
    $node->title = $candidate['title'];
    $node->field_original_source[$node->language][0]['url'] = $candidate['url'];
    $node->field_source_domain[$node->language][0]['value'] = parse_url($candidate['url'], PHP_URL_HOST);
    $node->field_source_type[$node->language][0]['value'] = $candidate['source_type'];
    $node->field_outlinks[$node->language][0]['value'] = $this->outlinks;
    $node->field_workflow[$node->language][0]['value'] = $this->workflow;
    if (!$this->isUserCandidate) {
      $node->body[$node->language][0]['value'] = t('This candidate to source has been proposed by the tool based on the outbound links found in the collection of items currently stored.\r\nTo help evaluate this source please leave your comment below.');
    }

    return $node;
  }

}
