<?php
/**
 * @file
 * Template for RSS feeds.
 *
 * Variables:
 * - $page: The rendered page content.
 */
?>
<?php print '<?xml version="1.0" encoding="utf-8"?>'; ?>

<rss version="2.0" xml:base="http://gipo.localhost/" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcmitype="http://purl.org/dc/dcmitype">
<?php print $page; ?>
</rss>
