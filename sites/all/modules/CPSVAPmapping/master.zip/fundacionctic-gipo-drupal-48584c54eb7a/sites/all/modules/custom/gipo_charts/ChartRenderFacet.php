<?php

/**
 * @file
 * Description of ChartRenderFacet.
 *
 * @author mikunis <miguel.garcia@fundacionctic.org>
 */

/**
 * .
 */
abstract class ChartRenderFacet {

  protected $facetName;
  protected $path;

  protected function __construct($facet, $path = '') {
    $this->facetName = $facet;
    $this->path = $path;
  }

  public function getFacetName() {
    return $this->facetName;
  }

  /**
   * Builds the drupal render array for the facets provided.
   *
   * @param object $facets
   *   Object of facets get from Solr.
   *
   * @return array
   *   Drupal render array.
   */
  public abstract function getRenderArray(stdClass $facets);

  protected function convertObjectFacetsToArray(stdClass $facets_fields) {
    if (isset($facets_fields->{$this->facetName})) {
      return (array) $facets_fields->{$this->facetName};
    } else {
      return array();
    }
  }

  /**
   * Calls the facetapi_link_inactive theme to render the facet link when it is inactive.
   *
   * @param string $query
   *   Query part of the facet link.
   * @param string $name
   *   Name of the facet, will be used as link text.
   * @param int $value
   *   Number of faceted items.
   *
   * @return array
   *   Render array as a list element.
   */
  protected function renderInactiveLinkFacet($query, $name, $value) {
    return array(
      'data' => theme('facetapi_link_inactive', array(
        'text' => t($name),
        'path' => $this->path,
        'options' => array(
          'attributes' => array(),
          'html' => FALSE,
          'query' => array(
            'f[0]' => $query,
          ),
        ),
        'count' => $value,
          )
      ),
      'class' => array('leaf'),
    );
  }

  /**
   * Calls the facetapi_link_active theme to render the facet link when it is active.
   *
   * @param string $query
   *   Query part of the facet link.
   * @param string $name
   *   Name of the facet, will be used as link text.
   * @param int $value
   *   Number of faceted items.
   *
   * @return array
   *   Render array as a list element.
   */
  protected function renderActiveLinkFacet($query, $name, $value) {
    return array(
      'data' => theme('facetapi_link_active', array(
        'text' => t($name),
        'path' => $this->path,
        'options' => array(
          'attributes' => array(),
          'html' => FALSE,
//          'query' => array(
//            'f[0]' => $query,
//          ),
        ),
        'count' => $value,
          )
      ),
      'class' => array('leaf'),
    );
  }

  /**
   * Checks if the facet is currently used in the search (is inactive).
   *
   * @param string $name
   *   The name of the a facet.
   * @param array $fq
   *   The array with the facet query send to the search engine (Solr).
   *
   * @return bool
   *   True if the facet is not include in the search, false if it is
   */
  protected function isInactiveLinkFacet($name, array $fq) {
    $normalized_name = $name;
    if (strstr($name, ' ')) {
      $normalized_name = "\"$normalized_name\"";
    }
    return array_search("$this->facetName:$normalized_name", $fq) === FALSE;
  }

}

/**
 * Creates the render array for TreeMap facets.
 */
class TreeMapChartRenderFacet extends ChartRenderFacet {

  public function __construct($facet) {
    parent::__construct($facet, '/');
  }

  /**
   * Gets the render array for a facet.
   *
   * @param object $facets
   *   A facet object as returned from a Solr search.
   *
   * @return array
   *   A Drupal render array for a facet.
   */
  public function getRenderArray(stdClass $facets) {
    $facets_array = $this->convertObjectFacetsToArray($facets->fields);
    if (count($facets_array)) {
      $items = array();
      foreach ($facets_array as $name => $value) {
        if ($value > 0) {
          if ($this->isInactiveLinkFacet($name, $facets->fq)) {
            $items[] = $this->renderInactiveLinkFacet("$this->facetName:$name", $name, $value);
          }
          else {
            $items[] = $this->renderActiveLinkFacet("$this->facetName:$name", $name, $value);
          }
        }
      }

      $content = theme('item_list', array(
        'items' => $items,
        'type' => 'ul',
        'attributes' => array('class' => 'facetapi-facetapi-links facetapi-facet-gipo-' . $this->facetName . ' facetapi-processed'),
          )
      );
      return array(
        'subject' => '',
        'content' => array(
          '#markup' => $content,
        ),
      );
    }
    else {
      return array(
        'subject' => '',
        'content' => array(
          '#markup' => '<p>No content found</p>',
        ),
      );
    }
  }

}

/**
 * Creates the render array for TreeMap facets.
 */
class TreeRenderFacet extends ChartRenderFacet {

  public function __construct($facet) {
    parent::__construct($facet, 'search/site/*');
  }

  public function getRenderArray(\stdClass $facets) {
    $facets_array = $this->convertObjectFacetsToArray($facets->fields);
    if (count($facets_array)) {
      $items = array();
      foreach ($facets_array as $name => $value) {
        if ($value > 0) {
          $items[] = $this->renderInactiveLinkFacet("aspects:$name", $name, $value);
        }
      }

      $content = theme('item_list', array(
        'items' => $items,
        'type' => 'ul',
        'attributes' => array('class' => 'search-topic search-topic-' . $this->facetName),
          )
      );
      return array(
        'subject' => t('Search by topic'),
        'content' => array(
          '#markup' => $content,
        ),
      );
    }
    else {
      return array(
        'subject' => t('Search by topic'),
        'content' => array(
          '#markup' => '<p>No topics found</p>',
        ),
      );
    }
  }

}
