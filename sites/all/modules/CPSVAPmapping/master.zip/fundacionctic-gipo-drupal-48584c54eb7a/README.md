# GIPO Drupal

## Introduction

Front Drupal-based GIPO

## Drupal distribution build (Profile)

Navigate to the repository root and launch drush make.

```
./drush-rebuild.sh
```
After execution a gipo-profile directory will be created with an installable Drupal distribution.

## Drupal instalation

Move gipo-profile directory to web server location and launch the following command. This will silently install a Drupal site.

```
drush si gipo_profile -y --db-url=mysql://root:root@localhost/gipo-distro --db-su=root --db-su-pw=root --account-name=admin --account-pass=admin
```
